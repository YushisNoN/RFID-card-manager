const boards = [
    { id: 'B-01', name: 'Плата №1' },
    { id: 'B-02', name: 'Плата №2' },
    { id: 'B-03', name: 'Плата №3' },
    { id: 'B-04', name: 'Плата №4' },
    { id: 'B-05', name: 'Плата №5' },
    { id: 'B-06', name: 'Плата №6' },
    { id: 'B-07', name: 'Плата №7' },
    { id: 'B-08', name: 'Плата №8' }
];

const users = ['Иванов', 'Петров', 'Сидоров', 'Козлов', 'Новиков', 'Морозов', 'Волков', 'Соколов'];

let logEntries = [];
let takeEvents = [];
let returnEvents = [];

function randomItem(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

function randomPastDate(maxDaysAgo) {
    const now = Date.now();
    const msAgo = Math.random() * maxDaysAgo * 24 * 60 * 60 * 1000;
    return new Date(now - msAgo);
}

function formatDate(date) {
    const d = String(date.getDate()).padStart(2, '0');
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const y = date.getFullYear();
    const hh = String(date.getHours()).padStart(2, '0');
    const mm = String(date.getMinutes()).padStart(2, '0');
    return `${d}.${m}.${y} ${hh}:${mm}`;
}

function formatDuration(ms) {
    const totalMinutes = Math.floor(ms / 60000);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    if (hours > 0) {
        return `${hours}ч ${minutes}м`;
    }
    return `${minutes}м`;
}

function generateLogs() {
    logEntries = [];
    takeEvents = [];
    returnEvents = [];

    const activeBoardIds = new Set();
    const sessions = [];

    const boardStatus = {};
    boards.forEach(b => {
        boardStatus[b.id] = { taken: false, takeTime: null, user: null };
    });

    const totalEvents = 40;
    const events = [];

    for (let i = 0; i < totalEvents; i++) {
        const board = randomItem(boards);
        const user = randomItem(users);
        const isTake = Math.random() < 0.5;
        const time = randomPastDate(30);
        events.push({ board, user, isTake, time });
    }

    events.sort((a, b) => a.time - b.time);

    const lastAction = {};

    events.forEach((ev, idx) => {
        const key = ev.board.id;
        if (ev.isTake) {
            if (lastAction[key] === 'take') return;
            lastAction[key] = 'take';
            takeEvents.push({ board: ev.board, user: ev.user, time: ev.time });
            logEntries.push({
                id: logEntries.length + 1,
                boardName: ev.board.name,
                action: 'взятие',
                actionType: 'take',
                time: ev.time,
                user: ev.user
            });
        } else {
            if (lastAction[key] !== 'take') return;
            lastAction[key] = 'return';
            returnEvents.push({ board: ev.board, user: ev.user, time: ev.time });
            logEntries.push({
                id: logEntries.length + 1,
                boardName: ev.board.name,
                action: 'отдача',
                actionType: 'return',
                time: ev.time,
                user: ev.user
            });
        }
    });

    logEntries.sort((a, b) => b.time - a.time);
}

function getSessions() {
    const sessions = [];
    const openTakes = {};

    const sortedTakes = [...takeEvents].sort((a, b) => a.time - b.time);
    const sortedReturns = [...returnEvents].sort((a, b) => a.time - b.time);

    sortedTakes.forEach(take => {
        const boardId = take.board.id;
        const matchingReturn = sortedReturns.find(r =>
            r.board.id === boardId && r.time > take.time
        );
        if (matchingReturn) {
            sessions.push({
                board: take.board,
                user: take.user,
                takeTime: take.time,
                returnTime: matchingReturn.time,
                duration: matchingReturn.time - take.time
            });
        }
    });

    return sessions;
}

function getAvailableCount() {
    const lastActions = {};
    const allEvents = [
        ...takeEvents.map(e => ({ ...e, type: 'take' })),
        ...returnEvents.map(e => ({ ...e, type: 'return' }))
    ].sort((a, b) => a.time - b.time);

    allEvents.forEach(ev => {
        lastActions[ev.board.id] = ev.type;
    });

    let available = 0;
    boards.forEach(b => {
        if (lastActions[b.id] !== 'take') {
            available++;
        }
    });

    return available;
}

function renderLogs() {
    const tbody = document.getElementById('log-body');
    tbody.innerHTML = '';

    logEntries.forEach(entry => {
        const tr = document.createElement('tr');

        const tdNum = document.createElement('td');
        tdNum.textContent = entry.id;

        const tdBoard = document.createElement('td');
        tdBoard.textContent = entry.boardName;

        const tdAction = document.createElement('td');
        tdAction.textContent = entry.action;
        tdAction.className = entry.actionType === 'take' ? 'action-take' : 'action-return';

        const tdTime = document.createElement('td');
        tdTime.textContent = formatDate(entry.time);

        const tdUser = document.createElement('td');
        tdUser.textContent = entry.user;

        tr.appendChild(tdNum);
        tr.appendChild(tdBoard);
        tr.appendChild(tdAction);
        tr.appendChild(tdTime);
        tr.appendChild(tdUser);

        tbody.appendChild(tr);
    });
}

function renderStock() {
    const available = getAvailableCount();
    const total = boards.length;
    const fill = document.getElementById('stock-fill');
    const text = document.getElementById('stock-text');

    const pct = total > 0 ? (available / total) * 100 : 0;
    fill.style.width = pct + '%';
    text.textContent = `${available}/${total}`;
}

function renderStats() {
    const sessions = getSessions();

    document.getElementById('stat-takes').textContent = takeEvents.length;
    document.getElementById('stat-returns').textContent = returnEvents.length;

    let avgMs = 0;
    if (sessions.length > 0) {
        const totalMs = sessions.reduce((sum, s) => sum + s.duration, 0);
        avgMs = totalMs / sessions.length;
    }

    document.getElementById('stat-avg').textContent = sessions.length > 0
        ? formatDuration(avgMs)
        : '—';

    const list = document.getElementById('stat-detail-list');
    list.innerHTML = '';

    sessions.slice(0, 20).forEach(s => {
        const li = document.createElement('li');

        const spanBoard = document.createElement('span');
        spanBoard.textContent = s.board.name + ' · ' + s.user;

        const spanTime = document.createElement('span');
        spanTime.className = 'sl-time';
        spanTime.textContent = formatDate(s.takeTime) + ' → ' + formatDate(s.returnTime);

        const spanDuration = document.createElement('span');
        spanDuration.className = 'sl-duration';
        spanDuration.textContent = formatDuration(s.duration);

        li.appendChild(spanBoard);
        li.appendChild(spanTime);
        li.appendChild(spanDuration);
        list.appendChild(li);
    });

    if (sessions.length === 0) {
        const li = document.createElement('li');
        li.textContent = 'нет завершённых сессий';
        list.appendChild(li);
    }
}

function refreshAll() {
    generateLogs();
    renderLogs();
    renderStock();
    renderStats();
}

function refreshStats() {
    renderStats();
}

function switchTab(tabName) {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelector(`.tab[data-tab="${tabName}"]`).classList.add('active');

    document.querySelectorAll('.panel').forEach(p => p.classList.add('hidden'));

    if (tabName === 'logs') {
        document.getElementById('logs-panel').classList.remove('hidden');
    } else if (tabName === 'stats') {
        document.getElementById('stats-panel').classList.remove('hidden');
        renderStats();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    refreshAll();

    document.querySelectorAll('.tab').forEach(tab => {
        tab.addEventListener('click', () => {
            switchTab(tab.dataset.tab);
        });
    });

    document.getElementById('refresh-btn').addEventListener('click', refreshAll);
    document.getElementById('refresh-side-btn').addEventListener('click', refreshAll);
    document.getElementById('refresh-footer-btn').addEventListener('click', refreshAll);
    document.getElementById('refresh-stats-btn').addEventListener('click', refreshStats);
});