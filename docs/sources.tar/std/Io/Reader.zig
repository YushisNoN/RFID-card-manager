const Reader = @This();

const builtin = @import("builtin");
const native_endian = builtin.target.cpu.arch.endian();

const std = @import("../std.zig");
const Writer = std.Io.Writer;
const Limit = std.Io.Limit;
const assert = std.debug.assert;
const testing = std.testing;
const Allocator = std.mem.Allocator;
const ArrayList = std.ArrayList;

pub const Limited = @import("Reader/Limited.zig");

vtable: *const VTable,
buffer: []u8,
/// Number of bytes which have been consumed from `buffer`.
seek: usize,
/// In `buffer` before this are buffered bytes, after this is `undefined`.
end: usize,

pub const VTable = struct {
    /// Writes bytes from the internally tracked logical position to `w`.
    ///
    /// Returns the number of bytes written, which will be at minimum `0` and
    /// at most `limit`. The number returned, including zero, does not indicate
    /// end of stream.
    ///
    /// The reader's internal logical seek position moves forward in accordance
    /// with the number of bytes returned from this function.
    ///
    /// Implementations are encouraged to utilize mandatory minimum buffer
    /// sizes combined with short reads (returning a value less than `limit`)
    /// in order to minimize complexity.
    ///
    /// Although this function is usually called when `buffer` is empty, it is
    /// also called when it needs to be filled more due to the API user
    /// requesting contiguous memory. In either case, the existing buffer data
    /// should be ignored; new data written to `w`.
    ///
    /// In addition to, or instead of writing to `w`, the implementation may
    /// choose to store data in `buffer`, modifying `seek` and `end`
    /// accordingly. Implementations are encouraged to take advantage of
    /// this if it simplifies the logic.
    stream: *const fn (r: *Reader, w: *Writer, limit: Limit) StreamError!usize,

    /// Consumes bytes from the internally tracked stream position without
    /// providing access to them.
    ///
    /// Returns the number of bytes discarded, which will be at minimum `0` and
    /// at most `limit`. The number of bytes returned, including zero, does not
    /// indicate end of stream.
    ///
    /// The reader's internal logical seek position moves forward in accordance
    /// with the number of bytes returned from this function.
    ///
    /// Implementations are encouraged to utilize mandatory minimum buffer
    /// sizes combined with short reads (returning a value less than `limit`)
    /// in order to minimize complexity.
    ///
    /// The default implementation is is based on calling `stream`, borrowing
    /// `buffer` to construct a temporary `Writer` and ignoring the written
    /// data.
    ///
    /// This function is only called when `buffer` is empty.
    discard: *const fn (r: *Reader, limit: Limit) Error!usize = defaultDiscard,

    /// Returns number of bytes written to `data`.
    ///
    /// `data` must have nonzero length. `data[0]` may have zero length, in
    /// which case the implementation must write to `Reader.buffer`.
    ///
    /// `data` may not contain an alias to `Reader.buffer`.
    ///
    /// `data` is mutable because the implementation may temporarily modify the
    /// fields in order to handle partial reads. Implementations must restore
    /// the original value before returning.
    ///
    /// Implementations may ignore `data`, writing directly to `Reader.buffer`,
    /// modifying `seek` and `end` accordingly, and returning 0 from this
    /// function. Implementations are encouraged to take advantage of this if
    /// it simplifies the logic.
    ///
    /// The default implementation calls `stream` with either `data[0]` or
    /// `Reader.buffer`, whichever is bigger.
    readVec: *const fn (r: *Reader, data: [][]u8) Error!usize = defaultReadVec,

    /// Ensures `capacity` data can be buffered without rebasing.
    ///
    /// Asserts `capacity` is within buffer capacity, or that the stream ends
    /// within `capacity` bytes.
    ///
    /// Only called when `capacity` cannot be satisfied by unused capacity of
    /// `buffer`.
    ///
    /// The default implementation moves buffered data to the start of
    /// `buffer`, setting `seek` to zero, and cannot fail.
    rebase: *const fn (r: *Reader, capacity: usize) RebaseError!void = defaultRebase,
};

pub const StreamError = error{
    /// See the `Reader` implementation for detailed diagnostics.
    ReadFailed,
    /// See the `Writer` implementation for detailed diagnostics.
    WriteFailed,
    /// End of stream indicated from the `Reader`. This error cannot originate
    /// from the `Writer`.
    EndOfStream,
};

pub const Error = error{
    /// See the `Reader` implementation for detailed diagnostics.
    ReadFailed,
    EndOfStream,
};

pub const StreamRemainingError = error{
    /// See the `Reader` implementation for detailed diagnostics.
    ReadFailed,
    /// See the `Writer` implementation for detailed diagnostics.
    WriteFailed,
};

pub const ShortError = error{
    /// See the `Reader` implementation for detailed diagnostics.
    ReadFailed,
};

pub const RebaseError = Error;

pub const failing: Reader = .{
    .vtable = &.{
        .stream = failingStream,
        .discard = failingDiscard,
    },
    .buffer = &.{},
    .seek = 0,
    .end = 0,
};

/// This is generally safe to `@constCast` because it has an empty buffer, so
/// there is not really a way to accidentally attempt mutation of these fields.
pub const ending_instance: Reader = .fixed(&.{});
pub const ending: *Reader = @constCast(&ending_instance);

pub fn limited(r: *Reader, limit: Limit, buffer: []u8) Limited {
    return .init(r, limit, buffer);
}

/// Constructs a `Reader` such that it will read from `buffer` and then end.
pub fn fixed(buffer: []const u8) Reader {
    return .{
        .vtable = &.{
            .stream = endingStream,
            .discard = endingDiscard,
            .readVec = endingReadVec,
            .rebase = endingRebase,
        },
        // This cast is safe because all potential writes to it will instead
        // return `error.EndOfStream`.
        .buffer = @constCast(buffer),
        .end = buffer.len,
        .seek = 0,
    };
}

pub fn stream(r: *Reader, w: *Writer, limit: Limit) StreamError!usize {
    const buffer = limit.slice(r.buffer[r.seek..r.end]);
    if (buffer.len > 0) {
        @branchHint(.likely);
        const n = try w.write(buffer);
        r.seek += n;
        return n;
    }
    const n = try r.vtable.stream(r, w, limit);
    assert(n <= @backingInt(limit));
    return n;
}

pub fn discard(r: *Reader, limit: Limit) Error!usize {
    const buffered_len = r.end - r.seek;
    const remaining: Limit = if (limit.toInt()) |n| l: {
        if (buffered_len >= n) {
            r.seek += n;
            return n;
        }
        break :l .limited(n - buffered_len);
    } else .unlimited;
    r.seek = r.end;
    const n = try r.vtable.discard(r, remaining);
    assert(n <= @backingInt(remaining));
    return buffered_len + n;
}

pub fn defaultDiscard(r: *Reader, limit: Limit) Error!usize {
    assert(r.seek == r.end);
    r.seek = 0;
    r.end = 0;
    var d: Writer.Discarding = .init(r.buffer);
    var n = r.stream(&d.writer, limit) catch |err| switch (err) {
        error.WriteFailed => unreachable,
        error.ReadFailed, error.EndOfStream => |e| return e,
    };
    // If `stream` wrote to `r.buffer` without going through the writer,
    // we need to discard as much of the buffered data as possible.
    const remaining = @backingInt(limit) - n;
    const buffered_n_to_discard = @min(remaining, r.end - r.seek);
    n += buffered_n_to_discard;
    r.seek += buffered_n_to_discard;
    assert(n <= @backingInt(limit));
    return n;
}

/// "Pump" exactly `n` bytes from the reader to the writer.
pub fn streamExact(r: *Reader, w: *Writer, n: usize) StreamError!void {
    var remaining = n;
    while (remaining != 0) remaining -= try r.stream(w, .limited(remaining));
}

/// "Pump" exactly `n` bytes from the reader to the writer.
pub fn streamExact64(r: *Reader, w: *Writer, n: u64) StreamError!void {
    var remaining = n;
    while (remaining != 0) remaining -= try r.stream(w, .limited64(remaining));
}

/// "Pump" exactly `n` bytes from the reader to the writer.
///
/// On success, at least `preserve_len` bytes will remain buffered if there are
/// enough buffered bytes to do so.
/// The amount buffered by the writer after the call will only be less than
/// `preserve_len` if `w.end + n` is less than `preserve_len` before the call.
/// The intentionally preserved bytes will include up to `preserve_len -| n` bytes from
/// the previously buffered bytes, plus `@min(n, preserve_len)` of the newly
/// "pumped" bytes.
///
/// Asserts `Writer.buffer` capacity is at least `preserve_len`.
/// `n` can be greater than the `Writer.buffer` capacity.
pub fn streamExactPreserve(r: *Reader, w: *Writer, preserve_len: usize, n: usize) StreamError!void {
    if (w.end + n <= w.buffer.len) {
        @branchHint(.likely);
        return streamExact(r, w, n);
    }
    // If `n` is large, we can ignore `preserve_len` up to a point.
    var remaining = n;
    while (remaining > preserve_len) {
        assert(remaining != 0);
        remaining -= try r.stream(w, .limited(remaining - preserve_len));
        if (w.end + remaining <= w.buffer.len) return streamExact(r, w, remaining);
    }
    // Offset the amount preserved by the amount we have left to stream
    // since the remaining bytes are always going to be part of that
    // preservation.
    try w.rebase(preserve_len -| remaining, remaining);
    return streamExact(r, w, remaining);
}

/// "Pump" data from the reader to the writer, handling `error.EndOfStream` as
/// a success case.
///
/// Returns total number of bytes written to `w`.
pub fn streamRemaining(r: *Reader, w: *Writer) StreamRemainingError!usize {
    var offset: usize = 0;
    while (true) {
        offset += r.stream(w, .unlimited) catch |err| switch (err) {
            error.EndOfStream => return offset,
            else => |e| return e,
        };
    }
}

/// Consumes the stream until the end, ignoring all the data, returning the
/// number of bytes discarded.
pub fn discardRemaining(r: *Reader) ShortError!usize {
    var offset: usize = r.end - r.seek;
    r.seek = r.end;
    while (true) {
        offset += r.vtable.discard(r, .unlimited) catch |err| switch (err) {
            error.EndOfStream => return offset,
            else => |e| return e,
        };
    }
}

pub const LimitedAllocError = Allocator.Error || ShortError || error{StreamTooLong};

/// Transfers all bytes from the current position to the end of the stream, up
/// to `limit`, returning them as a caller-owned allocated slice.
///
/// If `limit` is exceeded, `error.StreamTooLong` is returned instead.
/// In such case, the next byte that would be read will be one byte past the
/// first one to exceed `limit`, and all preceeding bytes have been discarded.
///
/// See also:
/// * `appendRemaining`
pub fn allocRemaining(r: *Reader, gpa: Allocator, limit: Limit) LimitedAllocError![]u8 {
    var buffer: ArrayList(u8) = .empty;
    defer buffer.deinit(gpa);

    try appendRemaining(r, gpa, &buffer, switch (limit) {
        .unlimited => limit,
        .nothing, _ => .limited(@backingInt(limit) + 1),
    });
    return buffer.toOwnedSlice(gpa);
}

pub fn allocRemainingAlignedSentinel(
    r: *Reader,
    gpa: Allocator,
    limit: Limit,
    comptime alignment: std.mem.Alignment,
    comptime sentinel: ?u8,
) LimitedAllocError!(if (sentinel) |s| [:s]align(alignment.toByteUnits()) u8 else []align(alignment.toByteUnits()) u8) {
    var buffer: std.array_list.Aligned(u8, alignment) = .empty;
    defer buffer.deinit(gpa);
    try appendRemainingAligned(r, gpa, alignment, &buffer, limit);
    if (sentinel) |s| {
        return buffer.toOwnedSliceSentinel(gpa, s);
    } else {
        return buffer.toOwnedSlice(gpa);
    }
}

pub const AppendExactError = Allocator.Error || Error;

/// Transfers exactly `n` bytes from the reader to the `ArrayList`.
///
/// See also:
/// * `appendRemaining`
pub fn appendExact(
    r: *Reader,
    gpa: Allocator,
    list: *ArrayList(u8),
    n: usize,
) AppendExactError!void {
    try list.ensureUnusedCapacity(gpa, n);
    var a = std.Io.Writer.Allocating.fromArrayList(gpa, list);
    defer list.* = a.toArrayList();
    streamExact(r, &a.writer, n) catch |err| switch (err) {
        error.ReadFailed, error.EndOfStream => |e| return e,
        error.WriteFailed => unreachable,
    };
}

/// Transfers all bytes from the current position to the end of the stream, up
/// to `limit`, appending them to `list`.
///
/// If `limit` is reached or exceeded, `error.StreamTooLong` is returned
/// instead. In such case, the next byte that would be read will be the first
/// one to exceed `limit`, and all preceeding bytes have been appended to
/// `list`.
///
/// See also:
/// * `allocRemaining`
pub fn appendRemaining(
    r: *Reader,
    gpa: Allocator,
    list: *ArrayList(u8),
    limit: Limit,
) LimitedAllocError!void {
    return appendRemainingAligned(r, gpa, .of(u8), list, limit);
}

/// Transfers all bytes from the current position to the end of the stream, up
/// to `limit`, appending them to `list`.
///
/// If `limit` is reached or exceeded, `error.StreamTooLong` is returned
/// instead. In such case, the next byte that would be read will be the first
/// one to exceed `limit`, and all preceeding bytes have been appended to
/// `list`.
///
/// See also:
/// * `appendRemaining`
/// * `allocRemainingAligned`
pub fn appendRemainingAligned(
    r: *Reader,
    gpa: Allocator,
    comptime alignment: std.mem.Alignment,
    list: *std.array_list.Aligned(u8, alignment),
    limit: Limit,
) LimitedAllocError!void {
    var a = std.Io.Writer.Allocating.fromArrayListAligned(gpa, alignment, list);
    defer list.* = a.toArrayListAligned(alignment);

    var remaining = limit;
    while (remaining != .nothing) {
        const n = stream(r, &a.writer, remaining) catch |err| switch (err) {
            error.EndOfStream => return,
            error.WriteFailed => return error.OutOfMemory,
            error.ReadFailed => |e| return e,
        };
        remaining = remaining.subtract(n).?;
    }
    return error.StreamTooLong;
}

pub const UnlimitedAllocError = Allocator.Error || ShortError;

pub fn appendRemainingUnlimited(r: *Reader, gpa: Allocator, list: *ArrayList(u8)) UnlimitedAllocError!void {
    list.pointer_stability.assertUnlocked();
    var a: std.Io.Writer.Allocating = .initOwnedSlice(gpa, list.allocatedSlice());
    a.writer.end = list.items.len;
    list.* = .empty;
    defer {
        list.* = .{
            .items = a.writer.buffer[0..a.writer.end],
            .capacity = a.writer.buffer.len,
            .pointer_stability = .{},
        };
    }
    _ = streamRemaining(r, &a.writer) catch |err| switch (err) {
        error.WriteFailed => return error.OutOfMemory,
        error.ReadFailed => |e| return e,
    };
}

/// Writes bytes from the internally tracked stream position to `data`.
///
/// Returns the number of bytes written, which will be at minimum `0` and
/// at most the sum of each data slice length. The number of bytes read,
/// including zero, does not indicate end of stream.
///
/// The reader's internal logical seek position moves forward in accordance
/// with the number of bytes returned from this function.
pub fn readVec(r: *Reader, data: [][]u8) Error!usize {
    var seek = r.seek;
    for (data, 0..) |buf, i| {
        const contents = r.buffer[seek..r.end];
        const copy_len = @min(contents.len, buf.len);
        @memcpy(buf[0..copy_len], contents[0..copy_len]);
        seek += copy_len;
        if (buf.len - copy_len == 0) continue;

        // All of `buffer` has been copied to `data`.
        const n = seek - r.seek;
        r.seek = seek;
        data[i] = buf[copy_len..];
        defer data[i] = buf;
        return n + (r.vtable.readVec(r, data[i..]) catch |err| switch (err) {
            error.EndOfStream => if (n == 0) return error.EndOfStream else 0,
            error.ReadFailed => |e| return e,
        });
    }
    const n = seek - r.seek;
    r.seek = seek;
    return n;
}

/// Writes to `Reader.buffer` or `data`, whichever has larger capacity.
pub fn defaultReadVec(r: *Reader, data: [][]u8) Error!usize {
    const first = data[0];
    if (first.len >= r.buffer.len - r.end) {
        var writer: Writer = .{
            .buffer = first,
            .end = 0,
            .vtable = &.{ .drain = Writer.fixedDrain },
        };
        const limit: Limit = .limited(writer.buffer.len - writer.end);
        return r.vtable.stream(r, &writer, limit) catch |err| switch (err) {
            error.WriteFailed => unreachable,
            else => |e| return e,
        };
    }
    var writer: Writer = .{
        .buffer = r.buffer,
        .end = r.end,
        .vtable = &.{ .drain = Writer.fixedDrain },
    };
    const limit: Limit = .limited(writer.buffer.len - writer.end);
    const n = r.vtable.stream(r, &writer, limit) catch |err| switch (err) {
        error.WriteFailed => unreachable,
        else => |e| return e,
    };
    r.end += n;
    return 0;
}

pub fn buffered(r: *Reader) []u8 {
    return r.buffer[r.seek..r.end];
}

pub fn bufferedLen(r: *const Reader) usize {
    return r.end - r.seek;
}

pub fn hashed(r: *Reader, hasher: anytype, buffer: []u8) Hashed(@TypeOf(hasher)) {
    return .init(r, hasher, buffer);
}

pub fn readVecAll(r: *Reader, data: [][]u8) Error!void {
    var index: usize = 0;
    var truncate: usize = 0;
    while (index < data.len) {
        {
            const untruncated = data[index];
            data[index] = untruncated[truncate..];
            defer data[index] = untruncated;
            truncate += try r.readVec(data[index..]);
        }
        while (index < data.len and truncate >= data[index].len) {
            truncate -= data[index].len;
            index += 1;
        }
    }
}

/// Returns the next `n` bytes from the stream, filling the buffer as
/// necessary.
///
/// Invalidates previously returned values from `peek`.
///
/// Asserts that the `Reader` was initialized with a buffer capacity at
/// least as big as `n`.
///
/// If there are fewer than `n` bytes left in the stream, `error.EndOfStream`
/// is returned instead.
///
/// See also:
/// * `toss`
pub fn peek(r: *Reader, n: usize) Error![]u8 {
    try r.fill(n);
    return r.buffer[r.seek..][0..n];
}

/// Returns all the next buffered bytes, after filling the buffer to ensure it
/// contains at least `n` bytes.
///
/// Invalidates previously returned values from `peek` and `peekGreedy`.
///
/// Asserts that the `Reader` was initialized with a buffer capacity at
/// least as big as `n`.
///
/// If there are fewer than `n` bytes left in the stream, `error.EndOfStream`
/// is returned instead.
///
/// See also:
/// * `peek`
/// * `toss`
pub fn peekGreedy(r: *Reader, n: usize) Error![]u8 {
    try r.fill(n);
    return r.buffer[r.seek..r.end];
}

/// Skips the next `n` bytes from the stream, advancing the seek position. This
/// is typically and safely used after `peek`.
///
/// Asserts that the number of bytes buffered is at least as many as `n`.
///
/// The "tossed" memory remains alive until a "peek" operation occurs.
///
/// See also:
/// * `peek`.
/// * `discard`.
pub fn toss(r: *Reader, n: usize) void {
    r.seek += n;
    assert(r.seek <= r.end);
}

/// Equivalent to `toss(r.bufferedLen())`.
pub fn tossBuffered(r: *Reader) void {
    r.seek = r.end;
}

/// Equivalent to `peek` followed by `toss`.
///
/// The data returned is invalidated by the next call to `take`, `peek`,
/// `fill`, and functions with those prefixes.
pub fn take(r: *Reader, n: usize) Error![]u8 {
    const result = try r.peek(n);
    r.toss(n);
    return result;
}

/// Returns the next `n` bytes from the stream as an array, filling the buffer
/// as necessary and advancing the seek position `n` bytes.
///
/// Asserts that the `Reader` was initialized with a buffer capacity at
/// least as big as `n`.
///
/// If there are fewer than `n` bytes left in the stream, `error.EndOfStream`
/// is returned instead.
///
/// See also:
/// * `take`
pub fn takeArray(r: *Reader, comptime n: usize) Error!*[n]u8 {
    return (try r.take(n))[0..n];
}

/// Returns the next `n` bytes from the stream as an array, filling the buffer
/// as necessary, without advancing the seek position.
///
/// Asserts that the `Reader` was initialized with a buffer capacity at
/// least as big as `n`.
///
/// If there are fewer than `n` bytes left in the stream, `error.EndOfStream`
/// is returned instead.
///
/// See also:
/// * `peek`
/// * `takeArray`
pub fn peekArray(r: *Reader, comptime n: usize) Error!*[n]u8 {
    return (try r.peek(n))[0..n];
}

/// Skips the next `n` bytes from the stream, advancing the seek position.
///
/// Unlike `toss` which is infallible, in this function `n` can be any amount.
///
/// Returns `error.EndOfStream` if fewer than `n` bytes could be discarded.
///
/// See also:
/// * `toss`
/// * `discardRemaining`
/// * `discardShort`
/// * `discard`
pub fn discardAll(r: *Reader, n: usize) Error!void {
    if ((try r.discardShort(n)) != n) return error.EndOfStream;
}

pub fn discardAll64(r: *Reader, n: u64) Error!void {
    var remaining: u64 = n;
    while (remaining > 0) {
        const limited_remaining = std.math.cast(usize, remaining) orelse std.math.maxInt(usize);
        try discardAll(r, limited_remaining);
        remaining -= limited_remaining;
    }
}

/// Skips the next `n` bytes from the stream, advancing the seek position.
///
/// Unlike `toss` which is infallible, in this function `n` can be any amount.
///
/// Returns the number of bytes discarded, which is less than `n` if and only
/// if the stream reached the end.
///
/// See also:
/// * `discardAll`
/// * `discardRemaining`
/// * `discard`
pub fn discardShort(r: *Reader, n: usize) ShortError!usize {
    const proposed_seek = r.seek + n;
    if (proposed_seek <= r.end) {
        @branchHint(.likely);
        r.seek = proposed_seek;
        return n;
    }
    var remaining = n - (r.end - r.seek);
    r.seek = r.end;
    while (true) {
        const discard_len = r.vtable.discard(r, .limited(remaining)) catch |err| switch (err) {
            error.EndOfStream => return n - remaining,
            error.ReadFailed => |e| return e,
        };
        remaining -= discard_len;
        if (remaining == 0) return n;
    }
}

/// Fill `buffer` with the next `buffer.len` bytes from the stream, advancing
/// the seek position.
///
/// Invalidates previously returned values from `peek`.
///
/// If the provided buffer cannot be filled completely, `error.EndOfStream` is
/// returned instead.
///
/// See also:
/// * `peek`
/// * `readSliceShort`
pub fn readSliceAll(r: *Reader, buffer: []u8) Error!void {
    const n = try readSliceShort(r, buffer);
    if (n != buffer.len) return error.EndOfStream;
}

/// Fill `buffer` with the next `buffer.len` bytes from the stream, advancing
/// the seek position.
///
/// Invalidates previously returned values from `peek`.
///
/// Returns the number of bytes read, which is less than `buffer.len` if and
/// only if the stream reached the end.
///
/// See also:
/// * `readSliceAll`
pub fn readSliceShort(r: *Reader, buffer: []u8) ShortError!usize {
    const contents = r.buffer[r.seek..r.end];
    const copy_len = @min(buffer.len, contents.len);
    @memcpy(buffer[0..copy_len], contents[0..copy_len]);
    r.seek += copy_len;
    if (buffer.len - copy_len == 0) {
        @branchHint(.likely);
        return buffer.len;
    }
    var i: usize = copy_len;
    var data: [1][]u8 = undefined;
    while (true) {
        data[0] = buffer[i..];
        i += readVec(r, &data) catch |err| switch (err) {
            error.EndOfStream => return i,
            error.ReadFailed => |e| return e,
        };
        if (buffer.len - i == 0) return buffer.len;
    }
}

/// Fill `buffer` with the next `buffer.len` bytes from the stream, advancing
/// the seek position.
///
/// Invalidates previously returned values from `peek`.
///
/// If the provided buffer cannot be filled completely, `error.EndOfStream` is
/// returned instead.
///
/// The function is inline to avoid the dead code in case `endian` is
/// comptime-known and matches host endianness.
///
/// See also:
/// * `readSliceAll`
/// * `readSliceEndianAlloc`
pub inline fn readSliceEndian(
    r: *Reader,
    comptime Elem: type,
    buffer: []Elem,
    endian: std.builtin.Endian,
) Error!void {
    try readSliceAll(r, @ptrCast(buffer));
    if (native_endian != endian) std.mem.byteSwapAllElements(Elem, buffer);
}

pub const ReadAllocError = Error || Allocator.Error;

/// The function is inline to avoid the dead code in case `endian` is
/// comptime-known and matches host endianness.
pub inline fn readSliceEndianAlloc(
    r: *Reader,
    allocator: Allocator,
    comptime Elem: type,
    len: usize,
    endian: std.builtin.Endian,
) ReadAllocError![]Elem {
    const dest = try allocator.alloc(Elem, len);
    errdefer allocator.free(dest);
    try r.readSliceEndian(Elem, dest, endian);
    return dest;
}

/// Deprecated; use readAllocAll. to be removed after 0.17.
pub const readAlloc = readAllocAll;

/// Shortcut for calling `readSliceAll` with a buffer provided by `allocator`.
pub fn readAllocAll(r: *Reader, allocator: Allocator, len: usize) ReadAllocError![]u8 {
    const dest = try allocator.alloc(u8, len);
    errdefer allocator.free(dest);
    try readSliceAll(r, dest);
    return dest;
}

/// Shortcut for calling `readSliceShort` with a buffer provided by `allocator`,
/// shrinking allocation if stream reached the end.
pub fn readAllocShort(r: *Reader, allocator: Allocator, len: usize) ReadAllocError![]u8 {
    const dest = try allocator.alloc(u8, len);
    errdefer allocator.free(dest);
    const n = try readSliceShort(r, dest);
    if (n == dest.len) return dest;
    return try allocator.realloc(dest, n);
}

pub const DelimiterError = error{
    /// See the `Reader` implementation for detailed diagnostics.
    ReadFailed,
    /// For "inclusive" functions, stream ended before the delimiter was found.
    /// For "exclusive" functions, stream ended and there are no more bytes to
    /// return.
    EndOfStream,
    /// The delimiter was not found within a number of bytes matching the
    /// capacity of the `Reader`.
    StreamTooLong,
};

/// Returns a slice of the next bytes of buffered data from the stream until
/// `sentinel` is found, advancing the seek position past the sentinel.
///
/// Returned slice has a sentinel.
///
/// Invalidates previously returned values from `peek`.
///
/// See also:
/// * `peekSentinel`
/// * `takeDelimiterExclusive`
/// * `takeDelimiterInclusive`
pub fn takeSentinel(r: *Reader, comptime sentinel: u8) DelimiterError![:sentinel]u8 {
    const result = try r.peekSentinel(sentinel);
    r.toss(result.len + 1);
    return result;
}

/// Returns a slice of the next bytes of buffered data from the stream until
/// `sentinel` is found, without advancing the seek position.
///
/// Returned slice has a sentinel; end of stream does not count as a delimiter.
///
/// Invalidates previously returned values from `peek`.
///
/// See also:
/// * `takeSentinel`
/// * `peekDelimiterExclusive`
/// * `peekDelimiterInclusive`
pub fn peekSentinel(r: *Reader, comptime sentinel: u8) DelimiterError![:sentinel]u8 {
    const result = try r.peekDelimiterInclusive(sentinel);
    return result[0 .. result.len - 1 :sentinel];
}

/// Returns a slice of the next bytes of buffered data from the stream until
/// `delimiter` is found, advancing the seek position past the delimiter.
///
/// Returned slice includes the delimiter as the last byte.
///
/// Invalidates previously returned values from `peek`.
///
/// See also:
/// * `takeSentinel`
/// * `takeDelimiterExclusive`
/// * `peekDelimiterInclusive`
pub fn takeDelimiterInclusive(r: *Reader, delimiter: u8) DelimiterError![]u8 {
    const result = try r.peekDelimiterInclusive(delimiter);
    r.toss(result.len);
    return result;
}

/// Returns a slice of the next bytes of buffered data from the stream until
/// `delimiter` is found, without advancing the seek position.
///
/// Returned slice includes the delimiter as the last byte.
///
/// Invalidates previously returned values from `peek`.
///
/// See also:
/// * `peekSentinel`
/// * `peekDelimiterExclusive`
/// * `takeDelimiterInclusive`
pub fn peekDelimiterInclusive(r: *Reader, delimiter: u8) DelimiterError![]u8 {
    {
        const contents = r.buffer[0..r.end];
        const seek = r.seek;
        if (std.mem.findScalarPos(u8, contents, seek, delimiter)) |end| {
            @branchHint(.likely);
            return contents[seek .. end + 1];
        }
    }
    while (true) {
        const content_len = r.end - r.seek;
        if (r.buffer.len - content_len == 0) break;
        try fillMore(r);
        const seek = r.seek;
        const contents = r.buffer[0..r.end];
        if (std.mem.findScalarPos(u8, contents, seek + content_len, delimiter)) |end| {
            return contents[seek .. end + 1];
        }
    }
    // It might or might not be end of stream. There is no more buffer space
    // left to disambiguate. If `StreamTooLong` was added to `RebaseError` then
    // this logic could be replaced by removing the exit condition from the
    // above while loop. That error code would represent when `buffer` capacity
    // is too small for an operation, replacing the current use of asserts.
    var failing_writer = Writer.failing;
    while (r.vtable.stream(r, &failing_writer, .limited(1))) |n| {
        assert(n == 0);
    } else |err| switch (err) {
        error.WriteFailed => return error.StreamTooLong,
        error.ReadFailed => |e| return e,
        error.EndOfStream => |e| return e,
    }
}

/// Returns a slice of the next bytes of buffered data from the stream until
/// `delimiter` is found, advancing the seek position up to (but not past)
/// the delimiter.
///
/// Returned slice excludes the delimiter. End-of-stream is treated equivalent
/// to a delimiter, unless it would result in a length 0 return value, in which
/// case `error.EndOfStream` is returned instead.
///
/// If the delimiter is not found within a number of bytes matching the
/// capacity of this `Reader`, `error.StreamTooLong` is returned. In
/// such case, the stream state is unmodified as if this function was never
/// called.
///
/// Invalidates previously returned values from `peek`.
///
/// See also:
/// * `takeDelimiter`
/// * `takeDelimiterInclusive`
/// * `peekDelimiterExclusive`
pub fn takeDelimiterExclusive(r: *Reader, delimiter: u8) DelimiterError![]u8 {
    const result = try r.peekDelimiterExclusive(delimiter);
    r.toss(result.len);
    return result;
}

/// Returns a slice of the next bytes of buffered data from the stream until
/// `delimiter` is found, advancing the seek position past the delimiter.
///
/// Returned slice excludes the delimiter. End-of-stream is treated equivalent
/// to a delimiter, unless it would result in a length 0 return value, in which
/// case `null` is returned instead.
///
/// If the delimiter is not found within a number of bytes matching the
/// capacity of this `Reader`, `error.StreamTooLong` is returned. In
/// such case, the stream state is unmodified as if this function was never
/// called.
///
/// Invalidates previously returned values from `peek`.
///
/// See also:
/// * `takeDelimiterInclusive`
/// * `takeDelimiterExclusive`
pub fn takeDelimiter(r: *Reader, delimiter: u8) error{ ReadFailed, StreamTooLong }!?[]u8 {
    const inclusive = r.peekDelimiterInclusive(delimiter) catch |err| switch (err) {
        error.EndOfStream => {
            const remaining = r.buffer[r.seek..r.end];
            if (remaining.len == 0) return null;
            r.toss(remaining.len);
            return remaining;
        },
        else => |e| return e,
    };
    r.toss(inclusive.len);
    return inclusive[0 .. inclusive.len - 1];
}

/// Returns a slice of the next bytes of buffered data from the stream until
/// `delimiter` is found, without advancing the seek position.
///
/// Returned slice excludes the delimiter. End-of-stream is treated equivalent
/// to a delimiter, unless it would result in a length 0 return value, in which
/// case `error.EndOfStream` is returned instead.
///
/// If the delimiter is not found within a number of bytes matching the
/// capacity of this `Reader`, `error.StreamTooLong` is returned. In
/// such case, the stream state is unmodified as if this function was never
/// called.
///
/// Invalidates previously returned values from `peek`.
///
/// See also:
/// * `peekDelimiterInclusive`
/// * `takeDelimiterExclusive`
pub fn peekDelimiterExclusive(r: *Reader, delimiter: u8) DelimiterError![]u8 {
    const result = r.peekDelimiterInclusive(delimiter) catch |err| switch (err) {
        error.EndOfStream => {
            const remaining = r.buffer[r.seek..r.end];
            if (remaining.len == 0) return error.EndOfStream;
            return remaining;
        },
        else => |e| return e,
    };
    return result[0 .. result.len - 1];
}

/// Appends to `w` contents by reading from the stream until `delimiter` is found.
/// Does not write the delimiter itself.
///
/// Does not discard the delimiter from the `Reader`.
///
/// Returns number of bytes streamed, which may be zero, or error.EndOfStream
/// if the delimiter was not found.
///
/// Asserts buffer capacity of at least one. This function performs better with
/// larger buffers.
///
/// See also:
/// * `streamDelimiterEnding`
/// * `streamDelimiterLimit`
pub fn streamDelimiter(r: *Reader, w: *Writer, delimiter: u8) StreamError!usize {
    const n = streamDelimiterLimit(r, w, delimiter, .unlimited) catch |err| switch (err) {
        error.StreamTooLong => unreachable, // unlimited is passed
        else => |e| return e,
    };
    if (r.seek == r.end) return error.EndOfStream;
    return n;
}

/// Appends to `w` contents by reading from the stream until `delimiter` is found.
/// Does not write the delimiter itself.
///
/// Does not discard the delimiter from the `Reader`.
///
/// Returns number of bytes streamed, which may be zero. If the stream reaches
/// the end, the reader buffer will be empty when this function returns.
/// Otherwise, it will have at least one byte buffered, starting with the
/// delimiter.
///
/// Asserts buffer capacity of at least one. This function performs better with
/// larger buffers.
///
/// See also:
/// * `streamDelimiter`
/// * `streamDelimiterLimit`
pub fn streamDelimiterEnding(
    r: *Reader,
    w: *Writer,
    delimiter: u8,
) StreamRemainingError!usize {
    return streamDelimiterLimit(r, w, delimiter, .unlimited) catch |err| switch (err) {
        error.StreamTooLong => unreachable, // unlimited is passed
        else => |e| return e,
    };
}

pub const StreamDelimiterLimitError = error{
    ReadFailed,
    WriteFailed,
    /// The delimiter was not found within the limit.
    StreamTooLong,
};

/// Appends to `w` contents by reading from the stream until `delimiter` is found.
/// Does not write the delimiter itself.
///
/// Does not discard the delimiter from the `Reader`.
///
/// Returns number of bytes streamed, which may be zero. End of stream can be
/// detected by checking if the next byte in the stream is the delimiter.
///
/// Asserts buffer capacity of at least one. This function performs better with
/// larger buffers.
pub fn streamDelimiterLimit(
    r: *Reader,
    w: *Writer,
    delimiter: u8,
    limit: Limit,
) StreamDelimiterLimitError!usize {
    var remaining = @backingInt(limit);
    while (remaining != 0) {
        const available = Limit.limited(remaining).slice(r.peekGreedy(1) catch |err| switch (err) {
            error.ReadFailed => |e| return e,
            error.EndOfStream => return @backingInt(limit) - remaining,
        });
        if (std.mem.findScalar(u8, available, delimiter)) |delimiter_index| {
            try w.writeAll(available[0..delimiter_index]);
            r.toss(delimiter_index);
            remaining -= delimiter_index;
            return @backingInt(limit) - remaining;
        }
        try w.writeAll(available);
        r.toss(available.len);
        remaining -= available.len;
    }
    return error.StreamTooLong;
}

/// Reads from the stream until specified byte is found, discarding all data,
/// including the delimiter.
///
/// Returns number of bytes discarded, or `error.EndOfStream` if the delimiter
/// is not found.
///
/// See also:
/// * `discardDelimiterExclusive`
/// * `discardDelimiterLimit`
pub fn discardDelimiterInclusive(r: *Reader, delimiter: u8) Error!usize {
    const n = discardDelimiterLimit(r, delimiter, .unlimited) catch |err| switch (err) {
        error.StreamTooLong => unreachable, // unlimited is passed
        else => |e| return e,
    };
    if (r.seek == r.end) return error.EndOfStream;
    assert(r.buffer[r.seek] == delimiter);
    toss(r, 1);
    return n + 1;
}

/// Reads from the stream until specified byte is found, discarding all data,
/// excluding the delimiter.
///
/// Returns the number of bytes discarded.
///
/// Succeeds if stream ends before delimiter found. End of stream can be
/// detected by checking if the delimiter is buffered.
///
/// See also:
/// * `discardDelimiterInclusive`
/// * `discardDelimiterLimit`
pub fn discardDelimiterExclusive(r: *Reader, delimiter: u8) ShortError!usize {
    return discardDelimiterLimit(r, delimiter, .unlimited) catch |err| switch (err) {
        error.StreamTooLong => unreachable, // unlimited is passed
        else => |e| return e,
    };
}

pub const DiscardDelimiterLimitError = error{
    ReadFailed,
    /// The delimiter was not found within the limit.
    StreamTooLong,
};

/// Reads from the stream until specified byte is found, discarding all data,
/// excluding the delimiter.
///
/// Returns the number of bytes discarded.
///
/// Succeeds if stream ends before delimiter found. End of stream can be
/// detected by checking if the delimiter is buffered.
pub fn discardDelimiterLimit(r: *Reader, delimiter: u8, limit: Limit) DiscardDelimiterLimitError!usize {
    var remaining = @backingInt(limit);
    while (remaining != 0) {
        const available = Limit.limited(remaining).slice(r.peekGreedy(1) catch |err| switch (err) {
            error.ReadFailed => |e| return e,
            error.EndOfStream => return @backingInt(limit) - remaining,
        });
        if (std.mem.findScalar(u8, available, delimiter)) |delimiter_index| {
            r.toss(delimiter_index);
            remaining -= delimiter_index;
            return @backingInt(limit) - remaining;
        }
        r.toss(available.len);
        remaining -= available.len;
    }
    return error.StreamTooLong;
}

/// Fills the buffer such that it contains at least `n` bytes, without
/// advancing the seek position.
///
/// Returns `error.EndOfStream` if and only if there are fewer than `n` bytes
/// remaining.
///
/// If the end of stream is not encountered, asserts buffer capacity is at
/// least `n`.
pub fn fill(r: *Reader, n: usize) Error!void {
    if (r.seek + n <= r.end) {
        @branchHint(.likely);
        return;
    }
    return fillUnbuffered(r, n);
}

/// This internal function is separated from `fill` to encourage optimizers to inline `fill`, hence
/// propagating its `@branchHint` to usage sites. If these functions are combined, `fill` is large
/// enough that LLVM is reluctant to inline it, forcing usages of APIs like `takeInt` to go through
/// an expensive runtime function call just to figure out that the data is, in fact, already in the
/// buffer.
///
/// Missing this optimization can result in wall-clock time for the most affected benchmarks
/// increasing by a factor of 5 or more.
fn fillUnbuffered(r: *Reader, n: usize) Error!void {
    try rebase(r, n);
    var bufs: [1][]u8 = .{""};
    while (r.end < r.seek + n) _ = try r.vtable.readVec(r, &bufs);
}

/// Without advancing the seek position, does exactly one underlying read, filling the buffer as
/// much as possible. This may result in zero bytes added to the buffer, which is not an end of
/// stream condition. End of stream is communicated via returning `error.EndOfStream`.
///
/// Asserts buffer capacity is at least 1.
pub fn fillMore(r: *Reader) Error!void {
    try rebase(r, r.end - r.seek + 1);
    var bufs: [1][]u8 = .{""};
    _ = try r.vtable.readVec(r, &bufs);
}

/// Returns the next byte from the stream or returns `error.EndOfStream`.
///
/// Does not advance the seek position.
///
/// Asserts the buffer capacity is nonzero.
pub fn peekByte(r: *Reader) Error!u8 {
    const buffer = r.buffer[0..r.end];
    const seek = r.seek;
    if (seek < buffer.len) {
        @branchHint(.likely);
        return buffer[seek];
    }
    try fill(r, 1);
    return r.buffer[r.seek];
}

/// Reads 1 byte from the stream or returns `error.EndOfStream`.
///
/// Asserts the buffer capacity is nonzero.
pub fn takeByte(r: *Reader) Error!u8 {
    const result = try peekByte(r);
    r.seek += 1;
    return result;
}

/// Same as `takeByte` except the returned byte is signed.
pub fn takeByteSigned(r: *Reader) Error!i8 {
    return @bitCast(try r.takeByte());
}

/// Asserts the buffer was initialized with a capacity at least `@bitSizeOf(T) / 8`.
pub inline fn takeInt(r: *Reader, comptime T: type, endian: std.builtin.Endian) Error!T {
    const n = @divExact(@typeInfo(T).int.bits, 8);
    return std.mem.readInt(T, try r.takeArray(n), endian);
}

/// Asserts the buffer was initialized with a capacity at least `@bitSizeOf(T) / 8`.
pub inline fn peekInt(r: *Reader, comptime T: type, endian: std.builtin.Endian) Error!T {
    const n = @divExact(@typeInfo(T).int.bits, 8);
    return std.mem.readInt(T, try r.peekArray(n), endian);
}

/// Asserts the buffer was initialized with a capacity at least `n`.
pub fn takeVarInt(r: *Reader, comptime Int: type, endian: std.builtin.Endian, n: usize) Error!Int {
    assert(n <= @sizeOf(Int));
    return std.mem.readVarInt(Int, try r.take(n), endian);
}

/// Obtains an unaligned pointer to the beginning of the stream, reinterpreted
/// as a pointer to the provided type, advancing the seek position.
///
/// Asserts the buffer was initialized with a capacity at least `@sizeOf(T)`.
///
/// See also:
/// * `peekStructPointer`
/// * `takeStruct`
pub fn takeStructPointer(r: *Reader, comptime T: type) Error!*align(1) T {
    // Only extern and packed structs have defined in-memory layout.
    comptime assert(@typeInfo(T).@"struct".layout != .auto);
    return @ptrCast(try r.takeArray(@sizeOf(T)));
}

/// Obtains an unaligned pointer to the beginning of the stream, reinterpreted
/// as a pointer to the provided type, without advancing the seek position.
///
/// Asserts the buffer was initialized with a capacity at least `@sizeOf(T)`.
///
/// See also:
/// * `takeStructPointer`
/// * `peekStruct`
pub fn peekStructPointer(r: *Reader, comptime T: type) Error!*align(1) T {
    // Only extern and packed structs have defined in-memory layout.
    comptime assert(@typeInfo(T).@"struct".layout != .auto);
    return @ptrCast(try r.peekArray(@sizeOf(T)));
}

/// This function is inline to avoid referencing `std.mem.byteSwapAllFields`
/// when `endian` is comptime-known and matches the host endianness.
///
/// See also:
/// * `takeStructPointer`
/// * `peekStruct`
pub inline fn takeStruct(r: *Reader, comptime T: type, endian: std.builtin.Endian) Error!T {
    switch (@typeInfo(T)) {
        .@"struct" => |info| switch (info.layout) {
            .auto => @compileError("ill-defined memory layout"),
            .@"extern" => {
                var res: T = undefined;
                try r.readSliceEndian(T, (&res)[0..1], endian);
                return res;
            },
            .@"packed" => {
                return @bitCast(try takeInt(r, info.backing_integer.?, endian));
            },
        },
        else => @compileError("not a struct"),
    }
}

/// Asserts the buffer was initialized with a capacity at least `@sizeOf(T)`.
///
/// This function is inline to avoid referencing `std.mem.byteSwapAllFields`
/// when `endian` is comptime-known and matches the host endianness.
///
/// See also:
/// * `takeStruct`
/// * `peekStructPointer`
pub inline fn peekStruct(r: *Reader, comptime T: type, endian: std.builtin.Endian) Error!T {
    switch (@typeInfo(T)) {
        .@"struct" => |info| switch (info.layout) {
            .auto => @compileError("ill-defined memory layout"),
            .@"extern" => {
                var res = (try r.peekStructPointer(T)).*;
                if (native_endian != endian) std.mem.byteSwapAllFields(T, &res);
                return res;
            },
            .@"packed" => {
                return @bitCast(try peekInt(r, info.backing_integer.?, endian));
            },
        },
        else => @compileError("not a struct"),
    }
}

pub const TakeEnumError = Error || error{InvalidEnumTag};

/// Reads an integer with the same size as the given enum's tag type. If the
/// integer matches an enum tag, casts the integer to the enum tag and returns
/// it. Otherwise, returns `error.InvalidEnumTag`.
///
/// Asserts the buffer was initialized with a capacity at least `@sizeOf(Enum)`.
pub fn takeEnum(r: *Reader, comptime Enum: type, endian: std.builtin.Endian) TakeEnumError!Enum {
    const Tag = @typeInfo(Enum).@"enum".tag_type;
    const int = try r.takeInt(Tag, endian);
    return std.enums.fromInt(Enum, int) orelse return error.InvalidEnumTag;
}

/// Reads an integer with the same size as the given nonexhaustive enum's tag type.
///
/// Asserts the buffer was initialized with a capacity at least `@sizeOf(Enum)`.
pub fn takeEnumNonexhaustive(r: *Reader, comptime Enum: type, endian: std.builtin.Endian) Error!Enum {
    const info = @typeInfo(Enum).@"enum";
    comptime assert(info.mode != .exhaustive);
    comptime assert(@bitSizeOf(info.tag_type) == @sizeOf(info.tag_type) * 8);
    return takeEnum(r, Enum, endian) catch |err| switch (err) {
        error.InvalidEnumTag => unreachable,
        else => |e| return e,
    };
}

pub const TakeLeb128Error = Error || error{Overflow};

/// Read a single LEB128 value as type T, or `error.Overflow` if the value cannot fit.
pub fn takeLeb128(r: *Reader, comptime T: type) TakeLeb128Error!T {
    const info = switch (@typeInfo(T)) {
        .int => |info| info,
        else => @compileError(@typeName(T) ++ " not supported"),
    };
    const Byte = packed struct { bits: u7, more: bool };

    if (info.bits <= 7) {
        var byte: Byte = undefined;
        const Bits = @Int(info.signedness, 7);

        byte = @bitCast(try r.takeByte());
        const val = std.math.cast(T, @as(Bits, @bitCast(byte.bits))) orelse error.Overflow;

        const allowed_bits: u7 = switch (info.signedness) {
            .unsigned => 0,
            .signed => @bitCast(@as(i7, @bitCast(byte.bits)) >> 6),
        };

        var fits = true;
        while (byte.more) {
            byte = @bitCast(try r.takeByte());

            if (byte.bits != allowed_bits) fits = false;
        }

        return if (fits) blk: {
            @branchHint(.likely);
            break :blk val;
        } else error.Overflow;
    }

    const Unsigned = @Int(.unsigned, info.bits);
    const UInt = std.math.ByteAlignedInt(Unsigned);
    const Int = std.math.ByteAlignedInt(T);

    const uint_bits = @typeInfo(UInt).int.bits;

    var byte: Byte = undefined;
    var val: UInt = 0;
    const max_bytes = @divFloor(info.bits - 1, 7) + 1;
    inline for (0..max_bytes) |iteration| {
        const shift = iteration * 7;

        byte = @bitCast(try r.takeByte());

        const extended: UInt = byte.bits;
        val |= extended << shift;

        const bits_written = shift + 7;

        if (bits_written >= info.bits) {
            const bits_overflowed = bits_written - info.bits;
            const bits_remaining = @mod(info.bits, 7);

            const allowed_bits: u7, var fits: bool = switch (info.signedness) {
                .unsigned => blk: {
                    const fits = bits_remaining == 0 or byte.bits >> bits_remaining == 0;

                    break :blk .{ 0, fits };
                },
                .signed => blk: {
                    const bits: i7 = @bitCast(byte.bits);

                    // Move the sign bit into the MSB
                    const shifted_bits: i7 = bits << bits_overflowed;

                    const value_sign: i7 = shifted_bits >> 6; // sign extends
                    const bits_sign: i7 = bits >> bits_remaining; // sign extends

                    const fits = bits_remaining == 0 or bits_sign == value_sign;

                    if (uint_bits != info.bits and value_sign != 0) {
                        const sign_extend_mask = @as(UInt, std.math.maxInt(UInt)) << info.bits;
                        val |= sign_extend_mask;
                    }

                    break :blk .{ @bitCast(value_sign), fits };
                },
            };

            switch (info.signedness) {
                .signed => assert(allowed_bits == 0 or allowed_bits == 0x7F),
                .unsigned => comptime assert(allowed_bits == 0),
            }

            while (byte.more) {
                byte = @bitCast(try r.takeByte());
                if (byte.bits != allowed_bits) fits = false;
            }

            return if (fits) blk: {
                @branchHint(.likely);
                break :blk std.math.cast(T, @as(Int, @bitCast(val))) orelse error.Overflow;
            } else error.Overflow;
        }

        comptime assert(bits_written < info.bits);
        if (!byte.more) {
            if (info.signedness == .signed and // can be negative
                byte.bits & 0x40 != 0) // is negative
            {
                const sign_extend_mask = @as(UInt, std.math.maxInt(UInt)) << bits_written;
                val |= sign_extend_mask;
            }
            return std.math.cast(T, @as(Int, @bitCast(val))) orelse error.Overflow;
        }
    }
}

/// Ensures `capacity` data can be buffered without rebasing.
pub fn rebase(r: *Reader, capacity: usize) Error!void {
    if (r.buffer.len - r.seek >= capacity) {
        @branchHint(.likely);
        return;
    }
    return r.vtable.rebase(r, capacity);
}

pub fn defaultRebase(r: *Reader, capacity: usize) Error!void {
    assert(r.buffer.len - r.seek < capacity);
    const data = r.buffer[r.seek..r.end];
    @memmove(r.buffer[0..data.len], data);
    r.seek = 0;
    r.end = data.len;
    assert(r.buffer.len - r.seek >= capacity);
}

test fixed {
    var r: Reader = .fixed("a\x02");
    try testing.expect((try r.takeByte()) == 'a');
    try testing.expect((try r.takeEnum(enum(u8) {
        a = 0,
        b = 99,
        c = 2,
        d = 3,
    }, builtin.cpu.arch.endian())) == .c);
    try testing.expectError(error.EndOfStream, r.takeByte());
}

test peek {
    var r: Reader = .fixed("abc");
    try testing.expectEqualStrings("ab", try r.peek(2));
    try testing.expectEqualStrings("a", try r.peek(1));
}

test peekGreedy {
    var r: Reader = .fixed("abc");
    try testing.expectEqualStrings("abc", try r.peekGreedy(1));
}

test toss {
    var r: Reader = .fixed("abc");
    r.toss(1);
    try testing.expectEqualStrings("bc", r.buffered());
}

test take {
    var r: Reader = .fixed("abc");
    try testing.expectEqualStrings("ab", try r.take(2));
    try testing.expectEqualStrings("c", try r.take(1));
}

test takeArray {
    var r: Reader = .fixed("abc");
    try testing.expectEqualStrings("ab", try r.takeArray(2));
    try testing.expectEqualStrings("c", try r.takeArray(1));
}

test peekArray {
    var r: Reader = .fixed("abc");
    try testing.expectEqualStrings("ab", try r.peekArray(2));
    try testing.expectEqualStrings("a", try r.peekArray(1));
}

test discardAll {
    var r: Reader = .fixed("foobar");
    try r.discardAll(3);
    try testing.expectEqualStrings("bar", try r.take(3));
    try r.discardAll(0);
    try testing.expectError(error.EndOfStream, r.discardAll(1));
}

test discardRemaining {
    var r: Reader = .fixed("foobar");
    r.toss(1);
    try testing.expectEqual(5, try r.discardRemaining());
    try testing.expectEqual(0, try r.discardRemaining());
}

test stream {
    var out_buffer: [10]u8 = undefined;
    var r: Reader = .fixed("foobar");
    var w: Writer = .fixed(&out_buffer);
    // Short streams are possible with this function but not with fixed.
    try testing.expectEqual(2, try r.stream(&w, .limited(2)));
    try testing.expectEqualStrings("fo", w.buffered());
    try testing.expectEqual(4, try r.stream(&w, .unlimited));
    try testing.expectEqualStrings("foobar", w.buffered());
}

test takeSentinel {
    var r: Reader = .fixed("ab\nc");
    try testing.expectEqualStrings("ab", try r.takeSentinel('\n'));
    try testing.expectError(error.EndOfStream, r.takeSentinel('\n'));
    try testing.expectEqualStrings("c", try r.peek(1));
}

test peekSentinel {
    var r: Reader = .fixed("ab\nc");
    try testing.expectEqualStrings("ab", try r.peekSentinel('\n'));
    try testing.expectEqualStrings("ab", try r.peekSentinel('\n'));
    r.toss(3);
    try testing.expectError(error.EndOfStream, r.peekSentinel('\n'));
    try testing.expectEqualStrings("c", try r.peek(1));
}

test takeDelimiterInclusive {
    var r: Reader = .fixed("ab\nc");
    try testing.expectEqualStrings("ab\n", try r.takeDelimiterInclusive('\n'));
    try testing.expectError(error.EndOfStream, r.takeDelimiterInclusive('\n'));
}

test peekDelimiterInclusive {
    var r: Reader = .fixed("ab\nc");
    try testing.expectEqualStrings("ab\n", try r.peekDelimiterInclusive('\n'));
    try testing.expectEqualStrings("ab\n", try r.peekDelimiterInclusive('\n'));
    r.toss(3);
    try testing.expectError(error.EndOfStream, r.peekDelimiterInclusive('\n'));
    try testing.expectEqualStrings("c", try r.peek(1));
}

test takeDelimiterExclusive {
    var r: Reader = .fixed("ab\nc");

    try testing.expectEqualStrings("ab", try r.takeDelimiterExclusive('\n'));
    try testing.expectEqualStrings("", try r.takeDelimiterExclusive('\n'));
    try testing.expectEqualStrings("", try r.takeDelimiterExclusive('\n'));
    try testing.expectEqualStrings("\n", try r.take(1));

    try testing.expectEqualStrings("c", try r.takeDelimiterExclusive('\n'));
    try testing.expectError(error.EndOfStream, r.takeDelimiterExclusive('\n'));
}

test peekDelimiterExclusive {
    var r: Reader = .fixed("ab\nc");

    try testing.expectEqualStrings("ab", try r.peekDelimiterExclusive('\n'));
    try testing.expectEqualStrings("ab", try r.peekDelimiterExclusive('\n'));
    r.toss(2);
    try testing.expectEqualStrings("", try r.peekDelimiterExclusive('\n'));
    try testing.expectEqualStrings("\n", try r.take(1));

    try testing.expectEqualStrings("c", try r.peekDelimiterExclusive('\n'));
    try testing.expectEqualStrings("c", try r.peekDelimiterExclusive('\n'));
    r.toss(1);
    try testing.expectError(error.EndOfStream, r.peekDelimiterExclusive('\n'));
}

test takeDelimiter {
    var r: Reader = .fixed("ab\nc\n\nd");
    try testing.expectEqualStrings("ab", (try r.takeDelimiter('\n')).?);
    try testing.expectEqualStrings("c", (try r.takeDelimiter('\n')).?);
    try testing.expectEqualStrings("", (try r.takeDelimiter('\n')).?);
    try testing.expectEqualStrings("d", (try r.takeDelimiter('\n')).?);
    try testing.expectEqual(null, try r.takeDelimiter('\n'));
    try testing.expectEqual(null, try r.takeDelimiter('\n'));

    r = .fixed("ab\nc\n\nd\n"); // one trailing newline does not affect behavior
    try testing.expectEqualStrings("ab", (try r.takeDelimiter('\n')).?);
    try testing.expectEqualStrings("c", (try r.takeDelimiter('\n')).?);
    try testing.expectEqualStrings("", (try r.takeDelimiter('\n')).?);
    try testing.expectEqualStrings("d", (try r.takeDelimiter('\n')).?);
    try testing.expectEqual(null, try r.takeDelimiter('\n'));
    try testing.expectEqual(null, try r.takeDelimiter('\n'));
}

test streamDelimiter {
    var out_buffer: [10]u8 = undefined;
    var r: Reader = .fixed("foo\nbars");
    var w: Writer = .fixed(&out_buffer);
    try testing.expectEqual(3, try r.streamDelimiter(&w, '\n'));
    try testing.expectEqualStrings("foo", w.buffered());
    try testing.expectEqual(0, try r.streamDelimiter(&w, '\n'));
    r.toss(1);
    try testing.expectError(error.EndOfStream, r.streamDelimiter(&w, '\n'));
}

test streamDelimiterEnding {
    var out_buffer: [10]u8 = undefined;
    var r: Reader = .fixed("foo\nbars");
    var w: Writer = .fixed(&out_buffer);
    try testing.expectEqual(3, try r.streamDelimiterEnding(&w, '\n'));
    try testing.expectEqualStrings("foo", w.buffered());
    r.toss(1);
    try testing.expectEqual(4, try r.streamDelimiterEnding(&w, '\n'));
    try testing.expectEqualStrings("foobars", w.buffered());
    try testing.expectEqual(0, try r.streamDelimiterEnding(&w, '\n'));
    try testing.expectEqual(0, try r.streamDelimiterEnding(&w, '\n'));
}

test streamDelimiterLimit {
    var out_buffer: [10]u8 = undefined;
    var r: Reader = .fixed("foo\nbars");
    var w: Writer = .fixed(&out_buffer);
    try testing.expectError(error.StreamTooLong, r.streamDelimiterLimit(&w, '\n', .limited(2)));
    try testing.expectEqual(1, try r.streamDelimiterLimit(&w, '\n', .limited(3)));
    try testing.expectEqualStrings("\n", try r.take(1));
    try testing.expectEqual(4, try r.streamDelimiterLimit(&w, '\n', .unlimited));
    try testing.expectEqualStrings("foobars", w.buffered());
}

test discardDelimiterExclusive {
    var r: Reader = .fixed("foob\nar");
    try testing.expectEqual(4, try r.discardDelimiterExclusive('\n'));
    try testing.expectEqualStrings("\n", try r.take(1));
    try testing.expectEqual(2, try r.discardDelimiterExclusive('\n'));
    try testing.expectEqual(0, try r.discardDelimiterExclusive('\n'));
}

test discardDelimiterInclusive {
    var r: Reader = .fixed("foob\nar");
    try testing.expectEqual(5, try r.discardDelimiterInclusive('\n'));
    try testing.expectError(error.EndOfStream, r.discardDelimiterInclusive('\n'));
}

test discardDelimiterLimit {
    var r: Reader = .fixed("foob\nar");
    try testing.expectError(error.StreamTooLong, r.discardDelimiterLimit('\n', .limited(4)));
    try testing.expectEqual(0, try r.discardDelimiterLimit('\n', .limited(2)));
    try testing.expectEqualStrings("\n", try r.take(1));
    try testing.expectEqual(2, try r.discardDelimiterLimit('\n', .unlimited));
    try testing.expectEqual(0, try r.discardDelimiterLimit('\n', .unlimited));
}

test fill {
    var r: Reader = .fixed("abc");
    try r.fill(1);
    try r.fill(3);
}

test takeByte {
    var r: Reader = .fixed("ab");
    try testing.expectEqual('a', try r.takeByte());
    try testing.expectEqual('b', try r.takeByte());
    try testing.expectError(error.EndOfStream, r.takeByte());
}

test takeByteSigned {
    var r: Reader = .fixed(&.{ 255, 5 });
    try testing.expectEqual(-1, try r.takeByteSigned());
    try testing.expectEqual(5, try r.takeByteSigned());
    try testing.expectError(error.EndOfStream, r.takeByteSigned());
}

test takeInt {
    var r: Reader = .fixed(&.{ 0x12, 0x34, 0x56 });
    try testing.expectEqual(0x1234, try r.takeInt(u16, .big));
    try testing.expectError(error.EndOfStream, r.takeInt(u16, .little));
}

test takeVarInt {
    var r: Reader = .fixed(&.{ 0x12, 0x34, 0x56 });
    try testing.expectEqual(0x123456, try r.takeVarInt(u64, .big, 3));
    try testing.expectError(error.EndOfStream, r.takeVarInt(u16, .little, 1));
}

test takeStructPointer {
    var r: Reader = .fixed(&.{ 0x12, 0x00, 0x34, 0x56 });
    const S = extern struct { a: u8, b: u16 };
    switch (native_endian) {
        .little => try testing.expectEqual(@as(S, .{ .a = 0x12, .b = 0x5634 }), (try r.takeStructPointer(S)).*),
        .big => try testing.expectEqual(@as(S, .{ .a = 0x12, .b = 0x3456 }), (try r.takeStructPointer(S)).*),
    }
    try testing.expectError(error.EndOfStream, r.takeStructPointer(S));
}

test peekStructPointer {
    var r: Reader = .fixed(&.{ 0x12, 0x00, 0x34, 0x56 });
    const S = extern struct { a: u8, b: u16 };
    switch (native_endian) {
        .little => {
            try testing.expectEqual(@as(S, .{ .a = 0x12, .b = 0x5634 }), (try r.peekStructPointer(S)).*);
            try testing.expectEqual(@as(S, .{ .a = 0x12, .b = 0x5634 }), (try r.peekStructPointer(S)).*);
        },
        .big => {
            try testing.expectEqual(@as(S, .{ .a = 0x12, .b = 0x3456 }), (try r.peekStructPointer(S)).*);
            try testing.expectEqual(@as(S, .{ .a = 0x12, .b = 0x3456 }), (try r.peekStructPointer(S)).*);
        },
    }
}

test takeStruct {
    var r: Reader = .fixed(&.{ 0x12, 0x00, 0x34, 0x56 });
    const S = extern struct { a: u8, b: u16 };
    try testing.expectEqual(@as(S, .{ .a = 0x12, .b = 0x3456 }), try r.takeStruct(S, .big));
    try testing.expectError(error.EndOfStream, r.takeStruct(S, .little));
}

test peekStruct {
    var r: Reader = .fixed(&.{ 0x12, 0x00, 0x34, 0x56 });
    const S = extern struct { a: u8, b: u16 };
    try testing.expectEqual(@as(S, .{ .a = 0x12, .b = 0x3456 }), try r.peekStruct(S, .big));
    try testing.expectEqual(@as(S, .{ .a = 0x12, .b = 0x5634 }), try r.peekStruct(S, .little));
}

test takeEnum {
    var r: Reader = .fixed(&.{ 2, 0, 1 });
    const E1 = enum(u8) { a, b, c };
    const E2 = enum(u16) { _ };
    try testing.expectEqual(E1.c, try r.takeEnum(E1, .little));
    try testing.expectEqual(@as(E2, @fromBackingInt(@intCast(0x0001))), try r.takeEnum(E2, .big));
}

test readSliceShort {
    var r: Reader = .fixed("HelloFren");
    var buf: [5]u8 = undefined;
    try testing.expectEqual(5, try r.readSliceShort(&buf));
    try testing.expectEqualStrings("Hello", buf[0..5]);
    try testing.expectEqual(4, try r.readSliceShort(&buf));
    try testing.expectEqualStrings("Fren", buf[0..4]);
    try testing.expectEqual(0, try r.readSliceShort(&buf));
}

test "readSliceShort with smaller buffer than Reader" {
    var reader_buf: [15]u8 = undefined;
    const str = "This is a test";
    var one_byte_stream: testing.Reader = .init(&reader_buf, &.{
        .{ .buffer = str },
    });
    one_byte_stream.artificial_limit = .limited(1);

    var buf: [14]u8 = undefined;
    try testing.expectEqual(14, try one_byte_stream.interface.readSliceShort(&buf));
    try testing.expectEqualStrings(str, &buf);
}

test "readSliceShort with indirect reader" {
    var r: Reader = .fixed("HelloFren");
    var ri_buf: [3]u8 = undefined;
    var ri: std.testing.ReaderIndirect = .init(&r, &ri_buf);
    var buf: [5]u8 = undefined;
    try testing.expectEqual(5, try ri.interface.readSliceShort(&buf));
    try testing.expectEqualStrings("Hello", buf[0..5]);
    try testing.expectEqual(4, try ri.interface.readSliceShort(&buf));
    try testing.expectEqualStrings("Fren", buf[0..4]);
    try testing.expectEqual(0, try ri.interface.readSliceShort(&buf));
}

test readAllocAll {
    const allocator = testing.allocator;
    var r: Reader = .fixed("HelloFren");

    const s1 = try r.readAllocAll(allocator, 5);
    defer allocator.free(s1);
    try testing.expectEqualStrings("Hello", s1);

    const s2 = try r.readAllocAll(allocator, 4);
    defer allocator.free(s2);
    try testing.expectEqualStrings("Fren", s2);
}

test "readAllocAll with buffer bigger than content" {
    const allocator = testing.allocator;
    var r: Reader = .fixed("HelloFren");

    const s1 = try r.readAllocAll(allocator, 5);
    defer allocator.free(s1);
    try testing.expectEqualStrings("Hello", s1);

    const res = r.readAllocAll(allocator, 10);
    try testing.expectError(Error.EndOfStream, res);
}

test readAllocShort {
    var r: Reader = .fixed("HelloFren");

    const s1 = try r.readAllocShort(testing.allocator, 5);
    defer testing.allocator.free(s1);
    try testing.expectEqualStrings("Hello", s1);

    const s2 = try r.readAllocShort(testing.allocator, 10);
    defer testing.allocator.free(s2);
    try testing.expectEqualStrings("Fren", s2);

    const s3 = try r.readAllocShort(testing.allocator, 10);
    defer testing.allocator.free(s3);
    try testing.expectEqual(0, s3.len);
}

test readVec {
    var r: Reader = .fixed(std.ascii.letters);
    var flat_buffer: [52]u8 = undefined;
    var bufs: [2][]u8 = .{
        flat_buffer[0..26],
        flat_buffer[26..],
    };
    // Short reads are possible with this function but not with fixed.
    try testing.expectEqual(26 * 2, try r.readVec(&bufs));
    try testing.expectEqualStrings(std.ascii.letters[0..26], bufs[0]);
    try testing.expectEqualStrings(std.ascii.letters[26..], bufs[1]);
}

test "expected error.EndOfStream" {
    // Unit test inspired by https://github.com/ziglang/zig/issues/17733
    var buffer: [3]u8 = undefined;
    var r: std.Io.Reader = .fixed(&buffer);
    r.end = 0; // capacity 3, but empty
    try std.testing.expectError(error.EndOfStream, r.takeEnum(enum(u8) { a, b }, .little));
    try std.testing.expectError(error.EndOfStream, r.take(3));
}

test "readVec at end" {
    var reader_buffer: [8]u8 = "abcd1234".*;
    var reader: testing.Reader = .init(&reader_buffer, &.{});
    reader.interface.end = reader_buffer.len;

    var out: [16]u8 = undefined;
    var vecs: [1][]u8 = .{&out};
    try testing.expectEqual(8, try reader.interface.readVec(&vecs));
    try testing.expectEqualStrings("abcd1234", vecs[0][0..8]);
}

fn endingStream(r: *Reader, w: *Writer, limit: Limit) StreamError!usize {
    _ = r;
    _ = w;
    _ = limit;
    return error.EndOfStream;
}

fn endingReadVec(r: *Reader, data: [][]u8) Error!usize {
    _ = r;
    _ = data;
    return error.EndOfStream;
}

fn endingDiscard(r: *Reader, limit: Limit) Error!usize {
    _ = r;
    _ = limit;
    return error.EndOfStream;
}

fn endingRebase(r: *Reader, capacity: usize) RebaseError!void {
    _ = r;
    _ = capacity;
    return error.EndOfStream;
}

fn failingStream(r: *Reader, w: *Writer, limit: Limit) StreamError!usize {
    _ = r;
    _ = w;
    _ = limit;
    return error.ReadFailed;
}

fn failingDiscard(r: *Reader, limit: Limit) Error!usize {
    _ = r;
    _ = limit;
    return error.ReadFailed;
}

test "discardAll that has to call discard multiple times on an indirect reader" {
    var fr: Reader = .fixed("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
    var indirect_buffer: [3]u8 = undefined;
    var tri: std.testing.ReaderIndirect = .init(&fr, &indirect_buffer);
    const r = &tri.interface;

    try r.discardAll(10);
    var remaining_buf: [16]u8 = undefined;
    try r.readSliceAll(&remaining_buf);
    try std.testing.expectEqualStrings(fr.buffer[10..], remaining_buf[0..]);
}

test "readAlloc when the backing reader provides one byte at a time" {
    const str = "This is a test";
    var tiny_buffer: [1]u8 = undefined;
    var one_byte_stream: testing.Reader = .init(&tiny_buffer, &.{
        .{ .buffer = str },
    });
    one_byte_stream.artificial_limit = .limited(1);
    const res = try one_byte_stream.interface.allocRemaining(std.testing.allocator, .unlimited);
    defer std.testing.allocator.free(res);
    try std.testing.expectEqualStrings(str, res);
}

test "takeDelimiterInclusive when it rebases" {
    const written_line = "ABCDEFGHIJKLMNOPQRSTUVWXYZ\n";
    var buffer: [128]u8 = undefined;
    var tr: std.testing.Reader = .init(&buffer, &.{
        .{ .buffer = written_line },
        .{ .buffer = written_line },
        .{ .buffer = written_line },
        .{ .buffer = written_line },
        .{ .buffer = written_line },
        .{ .buffer = written_line },
    });
    const r = &tr.interface;
    for (0..6) |_| {
        try std.testing.expectEqualStrings(written_line, try r.takeDelimiterInclusive('\n'));
    }
}

test "takeDelimiterInclusive on an indirect reader when it rebases" {
    const written_line = "ABCDEFGHIJKLMNOPQRSTUVWXYZ\n";
    var buffer: [128]u8 = undefined;
    var tr: std.testing.Reader = .init(&buffer, &.{
        .{ .buffer = written_line[0..4] },
        .{ .buffer = written_line[4..] },
        .{ .buffer = written_line },
        .{ .buffer = written_line },
        .{ .buffer = written_line },
        .{ .buffer = written_line },
        .{ .buffer = written_line },
    });
    var indirect_buffer: [128]u8 = undefined;
    var tri: std.testing.ReaderIndirect = .init(&tr.interface, &indirect_buffer);
    const r = &tri.interface;
    for (0..6) |_| {
        try std.testing.expectEqualStrings(written_line, try r.takeDelimiterInclusive('\n'));
    }
}

test "takeStruct and peekStruct packed" {
    var r: Reader = .fixed(&.{ 0b11110000, 0b00110011 });
    const S = packed struct(u16) { a: u2, b: u6, c: u7, d: u1 };

    try testing.expectEqual(@as(S, .{
        .a = 0b11,
        .b = 0b001100,
        .c = 0b1110000,
        .d = 0b1,
    }), try r.peekStruct(S, .big));

    try testing.expectEqual(@as(S, .{
        .a = 0b11,
        .b = 0b001100,
        .c = 0b1110000,
        .d = 0b1,
    }), try r.takeStruct(S, .big));

    try testing.expectError(error.EndOfStream, r.takeStruct(S, .little));
}

test allocRemaining {
    {
        var r: Reader = .fixed("abc");
        const str = try r.allocRemaining(testing.allocator, .unlimited);
        defer testing.allocator.free(str);
        try testing.expectEqualStrings("abc", str);
    }
    {
        var r: Reader = .fixed("abc");
        const str = try r.allocRemaining(testing.allocator, .limited(5));
        defer testing.allocator.free(str);
        try testing.expectEqualStrings("abc", str);
    }
    {
        var r: Reader = .fixed("abc");
        const str = try r.allocRemaining(testing.allocator, .limited(3));
        defer testing.allocator.free(str);
        try testing.expectEqualStrings("abc", str);
    }
    {
        var r: Reader = .fixed("abcd");
        try testing.expectError(error.StreamTooLong, r.allocRemaining(testing.allocator, .limited(3)));
    }
}

/// Provides a `Reader` implementation by passing data from an underlying
/// reader through `Hasher.update`.
///
/// The underlying reader is best unbuffered.
///
/// This implementation makes suboptimal buffering decisions due to being
/// generic. A better solution will involve creating a reader for each hash
/// function, where the discard buffer can be tailored to the hash
/// implementation details.
pub fn Hashed(comptime Hasher: type) type {
    return struct {
        in: *Reader,
        hasher: Hasher,
        reader: Reader,

        pub fn init(in: *Reader, hasher: Hasher, buffer: []u8) @This() {
            return .{
                .in = in,
                .hasher = hasher,
                .reader = .{
                    .vtable = &.{
                        .stream = @This().stream,
                        .readVec = @This().readVec,
                        .discard = @This().discard,
                    },
                    .buffer = buffer,
                    .end = 0,
                    .seek = 0,
                },
            };
        }

        fn stream(r: *Reader, w: *Writer, limit: Limit) StreamError!usize {
            const this: *@This() = @alignCast(@fieldParentPtr("reader", r));
            const data = limit.slice(try w.writableSliceGreedy(1));
            var vec: [1][]u8 = .{data};
            const n = try this.in.readVec(&vec);
            this.hasher.update(data[0..n]);
            w.advance(n);
            return n;
        }

        fn readVec(r: *Reader, data: [][]u8) Error!usize {
            const this: *@This() = @alignCast(@fieldParentPtr("reader", r));
            var vecs: [8][]u8 = undefined; // Arbitrarily chosen amount.
            const dest_n, const data_size = try r.writableVector(&vecs, data);
            const dest = vecs[0..dest_n];
            const n = try this.in.readVec(dest);
            var remaining: usize = n;
            for (dest) |slice| {
                if (remaining < slice.len) {
                    this.hasher.update(slice[0..remaining]);
                    remaining = 0;
                    break;
                } else {
                    remaining -= slice.len;
                    this.hasher.update(slice);
                }
            }
            assert(remaining == 0);
            if (n > data_size) {
                r.end += n - data_size;
                return data_size;
            }
            return n;
        }

        fn discard(r: *Reader, limit: Limit) Error!usize {
            const this: *@This() = @alignCast(@fieldParentPtr("reader", r));
            const peeked = limit.slice(try this.in.peekGreedy(1));
            this.hasher.update(peeked);
            this.in.toss(peeked.len);
            return peeked.len;
        }
    };
}

pub fn writableVectorPosix(r: *Reader, buffer: []std.posix.iovec, data: []const []u8) Error!struct { usize, usize } {
    var i: usize = 0;
    var n: usize = 0;
    if (r.seek == r.end) {
        for (data) |buf| {
            if (buffer.len - i == 0) return .{ i, n };
            if (buf.len != 0) {
                buffer[i] = .{ .base = buf.ptr, .len = buf.len };
                i += 1;
                n += buf.len;
            }
        }
        const buf = r.buffer;
        if (buf.len != 0) {
            r.seek = 0;
            r.end = 0;
            buffer[i] = .{ .base = buf.ptr, .len = buf.len };
            i += 1;
        }
    } else {
        const buf = r.buffer[r.end..];
        buffer[i] = .{ .base = buf.ptr, .len = buf.len };
        i += 1;
    }
    return .{ i, n };
}

pub fn writableVectorWsa(
    r: *Reader,
    buffer: []std.os.windows.AFD.WSABUF(.@"var"),
    data: []const []u8,
) Error!struct { usize, usize } {
    var i: usize = 0;
    var n: usize = 0;
    if (r.seek == r.end) {
        for (data) |buf| {
            if (buffer.len - i == 0) return .{ i, n };
            if (buf.len == 0) continue;
            if (std.math.cast(u32, buf.len)) |len| {
                buffer[i] = .{ .buf = buf.ptr, .len = len };
                i += 1;
                n += len;
                continue;
            }
            buffer[i] = .{ .buf = buf.ptr, .len = std.math.maxInt(u32) };
            i += 1;
            n += std.math.maxInt(u32);
            return .{ i, n };
        }
        const buf = r.buffer;
        if (buf.len != 0) {
            r.seek = 0;
            r.end = 0;
            if (std.math.cast(u32, buf.len)) |len| {
                buffer[i] = .{ .buf = buf.ptr, .len = len };
            } else {
                buffer[i] = .{ .buf = buf.ptr, .len = std.math.maxInt(u32) };
            }
            i += 1;
        }
    } else {
        buffer[i] = .{
            .buf = r.buffer.ptr + r.end,
            .len = @min(std.math.maxInt(u32), r.buffer.len - r.end),
        };
        i += 1;
    }
    return .{ i, n };
}

pub fn writableVector(r: *Reader, buffer: [][]u8, data: []const []u8) Error!struct { usize, usize } {
    var i: usize = 0;
    var n: usize = 0;
    if (r.seek == r.end) {
        for (data) |buf| {
            if (buffer.len - i == 0) return .{ i, n };
            if (buf.len != 0) {
                buffer[i] = buf;
                i += 1;
                n += buf.len;
            }
        }
        if (r.buffer.len != 0) {
            r.seek = 0;
            r.end = 0;
            buffer[i] = r.buffer;
            i += 1;
        }
    } else {
        buffer[i] = r.buffer[r.end..];
        i += 1;
    }
    return .{ i, n };
}

test "deserialize signed LEB128" {
    // Small values
    try testing.expectEqual(5, testLeb128(i7, "\x05"));
    try testing.expectEqual(53, testLeb128(i64, "\x35"));

    try testing.expectEqual(-6, testLeb128(i7, "\x7A"));
    try testing.expectEqual(-23, testLeb128(i64, "\x69"));

    // Random values
    try testing.expectEqual(90, testLeb128(i8, "\xDA\x00"));
    try testing.expectEqual(3434, testLeb128(i16, "\xEA\x1A"));
    try testing.expectEqual(1505683543, testLeb128(i32, "\xD7\xD0\xFB\xCD\x05"));
    try testing.expectEqual(105721575804011595, testLeb128(i64, "\xCB\x88\x92\xD7\xE8\xA6\xE6\xBB\x01"));
    try testing.expectEqual(51316697993548595875823294343650416388, testLeb128(i128, "\x84\xAE\xAC\xFC\xE4\xA0\xCD\xE2\x87\xED\x83\xB2\x87\xAA\xA3\x9E\x9B\xCD\x00"));

    try testing.expectEqual(-68, testLeb128(i8, "\xBC\x7F"));
    try testing.expectEqual(-20174, testLeb128(i16, "\xB2\xE2\x7E"));
    try testing.expectEqual(-166511141, testLeb128(i32, "\xDB\xFB\xCC\xB0\x7F"));
    try testing.expectEqual(-4368809844285451825, testLeb128(i64, "\xCF\xA3\x8B\xA1\xFF\xD2\xB7\xAF\x43"));
    try testing.expectEqual(-43250117698642799010758201165100952046, testLeb128(i128, "\x92\xAC\xDB\xA4\xEC\xDE\xB9\x95\xD1\xBA\xEC\xB0\xD7\x80\xA4\xAA\xF6\xBE\x7F"));

    // {min,max} values
    try testing.expectEqual(std.math.maxInt(i8), testLeb128(i8, "\xFF\x00"));
    try testing.expectEqual(std.math.maxInt(i16), testLeb128(i16, "\xFF\xFF\x01"));
    try testing.expectEqual(std.math.maxInt(i32), testLeb128(i32, "\xFF\xFF\xFF\xFF\x07"));
    try testing.expectEqual(std.math.maxInt(i64), testLeb128(i64, "\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x00"));
    try testing.expectEqual(std.math.maxInt(i128), testLeb128(i128, "\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x01"));

    try testing.expectEqual(std.math.minInt(i8), testLeb128(i8, "\x80\x7F"));
    try testing.expectEqual(std.math.minInt(i16), testLeb128(i16, "\x80\x80\x7E"));
    try testing.expectEqual(std.math.minInt(i32), testLeb128(i32, "\x80\x80\x80\x80\x78"));
    try testing.expectEqual(std.math.minInt(i64), testLeb128(i64, "\x80\x80\x80\x80\x80\x80\x80\x80\x80\x7F"));
    try testing.expectEqual(std.math.minInt(i128), testLeb128(i128, "\x80\x80\x80\x80\x80\x80\x80\x80\x80\x80\x80\x80\x80\x80\x80\x80\x80\x80\x7E"));

    // Specific cases
    try testing.expectEqual(0, testLeb128(i2, "\x00"));
    try testing.expectEqual(0, testLeb128(i8, "\x00"));

    try testing.expectEqual(1, testLeb128(i2, "\x01"));
    try testing.expectEqual(1, testLeb128(i8, "\x01"));

    try testing.expectEqual(-1, testLeb128(i2, "\x7F"));
    try testing.expectEqual(-1, testLeb128(i8, "\x7F"));

    const end_of_stream: [20]u8 = @splat(0x80);
    const overflow: [21]u8 = end_of_stream ++ .{0x01};
    const long_zero: [21]u8 = end_of_stream ++ .{0x00};
    const long_one: [22]u8 = .{0x81} ++ end_of_stream ++ .{0x00};
    const long_minus_one: [20]u8 = @as([19]u8, @splat(0xFF)) ++ .{0x7F};

    // Truncated
    try testing.expectError(error.EndOfStream, testLeb128(i16, "\x80\x80\x84\x80"));
    try testing.expectError(error.EndOfStream, testLeb128(i16, "\x80\x80\x80\x84\x80"));
    try testing.expectError(error.EndOfStream, testLeb128(i32, "\x80\x80\x80\x80\x90"));

    try testing.expectError(error.EndOfStream, testLeb128(i7, ""));
    try testing.expectError(error.EndOfStream, testLeb128(i8, ""));
    try testing.expectError(error.EndOfStream, testLeb128(i14, ""));
    try testing.expectError(error.EndOfStream, testLeb128(i128, ""));

    try testing.expectError(error.EndOfStream, testLeb128(i7, "\x80"));
    try testing.expectError(error.EndOfStream, testLeb128(i8, "\x80"));
    try testing.expectError(error.EndOfStream, testLeb128(i14, "\x80"));
    try testing.expectError(error.EndOfStream, testLeb128(i128, "\x80"));

    try testing.expectError(error.EndOfStream, testLeb128(i7, &end_of_stream));
    try testing.expectError(error.EndOfStream, testLeb128(i8, &end_of_stream));
    try testing.expectError(error.EndOfStream, testLeb128(i14, &end_of_stream));
    try testing.expectError(error.EndOfStream, testLeb128(i128, &end_of_stream));

    // Overflow
    try testing.expectError(error.Overflow, testLeb128(i8, "\x80\x01"));
    try testing.expectError(error.Overflow, testLeb128(i8, "\xFF\x7E"));
    try testing.expectError(error.Overflow, testLeb128(i8, "\x80\x80\x40"));
    try testing.expectError(error.Overflow, testLeb128(i16, "\x80\x80\x80\x40"));
    try testing.expectError(error.Overflow, testLeb128(i32, "\x80\x80\x80\x80\x08"));
    try testing.expectError(error.Overflow, testLeb128(i32, "\x80\x80\x80\x80\x40"));
    try testing.expectError(error.Overflow, testLeb128(i64, "\x80\x80\x80\x80\x80\x80\x80\x80\x80\x01"));
    try testing.expectError(error.Overflow, testLeb128(i64, "\x80\x80\x80\x80\x80\x80\x80\x80\x80\x40"));

    try testing.expectError(error.Overflow, testLeb128(i7, &overflow));
    try testing.expectError(error.Overflow, testLeb128(i8, &overflow));
    try testing.expectError(error.Overflow, testLeb128(i14, &overflow));
    try testing.expectError(error.Overflow, testLeb128(i128, &overflow));

    // Extra padding
    try testing.expectEqual(-1, testLeb128(i32, "\xFF\xFF\xFF\xFF\x7F"));
    try testing.expectEqual(-1, testLeb128(i64, "\xFF\x7F"));
    try testing.expectEqual(0x7F, testLeb128(i64, "\xFF\x00"));
    try testing.expectEqual(0x7F, testLeb128(i64, "\xFF\x80\x00"));
    try testing.expectEqual(0x80, testLeb128(i64, "\x80\x81\x00"));
    try testing.expectEqual(0x80, testLeb128(i64, "\x80\x81\x80\x00"));

    try testing.expectEqual(0, testLeb128(i7, &long_zero));
    try testing.expectEqual(0, testLeb128(i8, &long_zero));
    try testing.expectEqual(0, testLeb128(i14, &long_zero));
    try testing.expectEqual(0, testLeb128(i128, &long_zero));

    try testing.expectEqual(1, testLeb128(i2, &long_one));
    try testing.expectEqual(1, testLeb128(i7, &long_one));
    try testing.expectEqual(1, testLeb128(i8, &long_one));
    try testing.expectEqual(1, testLeb128(i14, &long_one));
    try testing.expectEqual(1, testLeb128(i128, &long_one));

    try testing.expectEqual(-1, testLeb128(i2, &long_minus_one));
    try testing.expectEqual(-1, testLeb128(i7, &long_minus_one));
    try testing.expectEqual(-1, testLeb128(i8, &long_minus_one));
    try testing.expectEqual(-1, testLeb128(i14, &long_minus_one));
    try testing.expectEqual(-1, testLeb128(i128, &long_minus_one));

    // Decode byte boundaries
    try testing.expectEqual(std.math.maxInt(i7), testLeb128(i7, "\x3F"));
    try testing.expectEqual(std.math.maxInt(i7) + 1, testLeb128(i8, "\xC0\x00"));
    try testing.expectEqual(std.math.maxInt(i14), testLeb128(i14, "\xFF\x3F"));
    try testing.expectEqual(std.math.maxInt(i14) + 1, testLeb128(i15, "\x80\xC0\x00"));
    try testing.expectEqual(std.math.maxInt(i49), testLeb128(i49, "\xFF\xFF\xFF\xFF\xFF\xFF\x3F"));
    try testing.expectEqual(std.math.maxInt(i49) + 1, testLeb128(i50, "\x80\x80\x80\x80\x80\x80\xC0\x00"));
    try testing.expectEqual(std.math.maxInt(i56), testLeb128(i56, "\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x3F"));
    try testing.expectEqual(std.math.maxInt(i56) + 1, testLeb128(i57, "\x80\x80\x80\x80\x80\x80\x80\xC0\x00"));
    try testing.expectEqual(std.math.maxInt(i63), testLeb128(i63, "\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x3F"));
    try testing.expectEqual(std.math.maxInt(i63) + 1, testLeb128(i64, "\x80\x80\x80\x80\x80\x80\x80\x80\xC0\x00"));

    try testing.expectEqual(std.math.minInt(i7), testLeb128(i7, "\x40"));
    try testing.expectEqual(std.math.minInt(i7) - 1, testLeb128(i8, "\xBF\x7F"));
    try testing.expectEqual(std.math.minInt(i14), testLeb128(i14, "\x80\x40"));
    try testing.expectEqual(std.math.minInt(i14) - 1, testLeb128(i15, "\xFF\xBF\x7F"));
    try testing.expectEqual(std.math.minInt(i49), testLeb128(i49, "\x80\x80\x80\x80\x80\x80\x40"));
    try testing.expectEqual(std.math.minInt(i49) - 1, testLeb128(i50, "\xFF\xFF\xFF\xFF\xFF\xFF\xBF\x7F"));
    try testing.expectEqual(std.math.minInt(i56), testLeb128(i56, "\x80\x80\x80\x80\x80\x80\x80\x40"));
    try testing.expectEqual(std.math.minInt(i56) - 1, testLeb128(i57, "\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xBF\x7F"));
    try testing.expectEqual(std.math.minInt(i63), testLeb128(i63, "\x80\x80\x80\x80\x80\x80\x80\x80\x40"));
    try testing.expectEqual(std.math.minInt(i63) - 1, testLeb128(i64, "\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xBF\x7F"));
}

test "deserialize unsigned LEB128" {
    // Small values
    try testing.expectEqual(46, testLeb128(u7, "\x2E"));
    try testing.expectEqual(117, testLeb128(u64, "\x75"));

    // Random values
    try testing.expectEqual(224, testLeb128(u8, "\xE0\x01"));
    try testing.expectEqual(53023, testLeb128(u16, "\x9F\x9E\x03"));
    try testing.expectEqual(2609971022, testLeb128(u32, "\xCE\xFE\xC3\xDC\x09"));
    try testing.expectEqual(10223253173206528843, testLeb128(u64, "\xCB\xE6\xF0\xEE\x88\xD3\x92\xF0\x8D\x01"));
    try testing.expectEqual(67831258924174241363439488509570048548, testLeb128(u128, "\xA4\xC4\xD7\xE9\x8C\xD2\x86\x80\xBC\xAC\xE5\xAB\xB4\xA2\xD1\xE9\x87\x66"));

    // max values
    try testing.expectEqual(std.math.maxInt(u8), testLeb128(u8, "\xFF\x01"));
    try testing.expectEqual(std.math.maxInt(u16), testLeb128(u16, "\xFF\xFF\x03"));
    try testing.expectEqual(std.math.maxInt(u32), testLeb128(u32, "\xFF\xFF\xFF\xFF\x0F"));
    try testing.expectEqual(std.math.maxInt(u64), testLeb128(u64, "\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x01"));
    try testing.expectEqual(std.math.maxInt(u128), testLeb128(u128, "\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x03"));

    // Specific cases
    try testing.expectEqual(0, testLeb128(u0, "\x00"));
    try testing.expectEqual(0, testLeb128(u1, "\x00"));
    try testing.expectEqual(0, testLeb128(u8, "\x00"));

    try testing.expectEqual(1, testLeb128(u1, "\x01"));
    try testing.expectEqual(1, testLeb128(u8, "\x01"));

    const end_of_stream: [20]u8 = @splat(0x80);
    const overflow: [21]u8 = end_of_stream ++ .{0x01};
    const long_zero: [21]u8 = end_of_stream ++ .{0x00};
    const long_one: [22]u8 = .{0x81} ++ end_of_stream ++ .{0x00};

    // Truncated
    try testing.expectError(error.EndOfStream, testLeb128(u16, "\x80\x80\x84\x80"));
    try testing.expectError(error.EndOfStream, testLeb128(u16, "\x80\x80\x80\x84\x80"));
    try testing.expectError(error.EndOfStream, testLeb128(u32, "\x80\x80\x80\x80\x90"));

    try testing.expectError(error.EndOfStream, testLeb128(u7, ""));
    try testing.expectError(error.EndOfStream, testLeb128(u8, ""));
    try testing.expectError(error.EndOfStream, testLeb128(u14, ""));
    try testing.expectError(error.EndOfStream, testLeb128(u128, ""));

    try testing.expectError(error.EndOfStream, testLeb128(u7, "\x80"));
    try testing.expectError(error.EndOfStream, testLeb128(u8, "\x80"));
    try testing.expectError(error.EndOfStream, testLeb128(u14, "\x80"));
    try testing.expectError(error.EndOfStream, testLeb128(u128, "\x80"));

    try testing.expectError(error.EndOfStream, testLeb128(u7, &end_of_stream));
    try testing.expectError(error.EndOfStream, testLeb128(u8, &end_of_stream));
    try testing.expectError(error.EndOfStream, testLeb128(u14, &end_of_stream));
    try testing.expectError(error.EndOfStream, testLeb128(u128, &end_of_stream));

    // Overflow
    try testing.expectError(error.Overflow, testLeb128(u0, "\x01"));
    try testing.expectError(error.Overflow, testLeb128(u1, "\x02"));
    try testing.expectError(error.Overflow, testLeb128(u8, "\x80\x02"));
    try testing.expectError(error.Overflow, testLeb128(u8, "\x80\x80\x40"));
    try testing.expectError(error.Overflow, testLeb128(u16, "\x80\x80\x80\x40"));
    try testing.expectError(error.Overflow, testLeb128(u32, "\x80\x80\x80\x80\x40"));
    try testing.expectError(error.Overflow, testLeb128(u64, "\x80\x80\x80\x80\x80\x80\x80\x80\x80\x40"));

    try testing.expectError(error.Overflow, testLeb128(u7, &overflow));
    try testing.expectError(error.Overflow, testLeb128(u8, &overflow));
    try testing.expectError(error.Overflow, testLeb128(u14, &overflow));
    try testing.expectError(error.Overflow, testLeb128(u128, &overflow));

    // Extra padding
    try testing.expectEqual(0x7F, testLeb128(u64, "\xFF\x00"));
    try testing.expectEqual(0x7F, testLeb128(u64, "\xFF\x80\x00"));
    try testing.expectEqual(0x80, testLeb128(u64, "\x80\x81\x00"));
    try testing.expectEqual(0x80, testLeb128(u64, "\x80\x81\x80\x80\x00"));

    try testing.expectEqual(0, testLeb128(u0, &long_zero));
    try testing.expectEqual(0, testLeb128(u7, &long_zero));
    try testing.expectEqual(0, testLeb128(u8, &long_zero));
    try testing.expectEqual(0, testLeb128(u14, &long_zero));
    try testing.expectEqual(0, testLeb128(u128, &long_zero));

    try testing.expectEqual(1, testLeb128(u1, &long_one));
    try testing.expectEqual(1, testLeb128(u7, &long_one));
    try testing.expectEqual(1, testLeb128(u8, &long_one));
    try testing.expectEqual(1, testLeb128(u14, &long_one));
    try testing.expectEqual(1, testLeb128(u128, &long_one));

    // Decode byte boundaries
    try testing.expectEqual(std.math.maxInt(u7), testLeb128(u7, "\x7F"));
    try testing.expectEqual(std.math.maxInt(u7) + 1, testLeb128(u8, "\x80\x01"));
    try testing.expectEqual(std.math.maxInt(u14), testLeb128(u14, "\xFF\x7F"));
    try testing.expectEqual(std.math.maxInt(u14) + 1, testLeb128(u15, "\x80\x80\x01"));
    try testing.expectEqual(std.math.maxInt(u49), testLeb128(u49, "\xFF\xFF\xFF\xFF\xFF\xFF\x7F"));
    try testing.expectEqual(std.math.maxInt(u49) + 1, testLeb128(u50, "\x80\x80\x80\x80\x80\x80\x80\x01"));
    try testing.expectEqual(std.math.maxInt(u56), testLeb128(u56, "\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x7F"));
    try testing.expectEqual(std.math.maxInt(u56) + 1, testLeb128(u57, "\x80\x80\x80\x80\x80\x80\x80\x80\x01"));
    try testing.expectEqual(std.math.maxInt(u63), testLeb128(u63, "\xFF\xFF\xFF\xFF\xFF\xFF\xFF\xFF\x7F"));
    try testing.expectEqual(std.math.maxInt(u63) + 1, testLeb128(u64, "\x80\x80\x80\x80\x80\x80\x80\x80\x80\x01"));
}

fn testLeb128(comptime T: type, encoded: []const u8) !T {
    var reader: std.Io.Reader = .fixed(encoded);
    const result = reader.takeLeb128(T);
    try testing.expectEqual(reader.seek, reader.end);
    return result;
}

test streamExactPreserve {
    try testStreamExactPreserve(.{ .buf_len = 10, .fill_len = 5, .preserve = 5, .stream_len = 5 });
    try testStreamExactPreserve(.{ .buf_len = 10, .fill_len = 9, .preserve = 5, .stream_len = 2 });
    try testStreamExactPreserve(.{ .buf_len = 10, .fill_len = 5, .preserve = 5, .stream_len = 6 });
    try testStreamExactPreserve(.{ .buf_len = 10, .fill_len = 5, .preserve = 6, .stream_len = 6 });
    try testStreamExactPreserve(.{ .buf_len = 10, .fill_len = 5, .preserve = 5, .stream_len = 10 });
    try testStreamExactPreserve(.{ .buf_len = 10, .fill_len = 5, .preserve = 6, .stream_len = 10 });
    try testStreamExactPreserve(.{ .buf_len = 10, .fill_len = 5, .preserve = 6, .stream_len = 11 });
    try testStreamExactPreserve(.{ .buf_len = 10, .fill_len = 5, .preserve = 6, .stream_len = 80 });
    try testStreamExactPreserve(.{ .buf_len = 10, .fill_len = 5, .preserve = 6, .stream_len = 85 });
    try testStreamExactPreserve(.{ .buf_len = 10, .fill_len = 5, .preserve = 10, .stream_len = 6 });
    try testStreamExactPreserve(.{ .buf_len = 10, .fill_len = 5, .preserve = 10, .stream_len = 11 });
    try testStreamExactPreserve(.{ .buf_len = 10, .fill_len = 5, .preserve = 10, .stream_len = 80 });
    try testStreamExactPreserve(.{ .buf_len = 10, .fill_len = 5, .preserve = 10, .stream_len = 85 });
}

fn testStreamExactPreserve(options: struct { buf_len: u4, fill_len: u4, preserve: u4, stream_len: u8 }) !void {
    assert(options.fill_len <= options.buf_len);
    assert(options.preserve <= options.buf_len);

    var input: [256]u8 = undefined;
    for (&input, 0..) |*val, i| {
        val.* = @as(u8, @intCast(i % 26)) + 'a';
    }
    const expected_out = input[0 .. options.fill_len + options.stream_len];
    const expected_preserved = expected_out[expected_out.len -| options.preserve..];

    var r: Reader = .fixed(&input);
    var out_buf: [256]u8 = undefined;
    var fw: Writer = .fixed(&out_buf);
    var indirect_buffer: [16]u8 = undefined;
    var twi: std.testing.WriterIndirect = .init(&fw, indirect_buffer[0..options.buf_len]);
    const w = &twi.interface;

    try r.streamExact(w, options.fill_len);
    try r.streamExactPreserve(w, options.preserve, options.stream_len);

    try std.testing.expectEqualStrings(expected_preserved, w.buffer[w.end -| options.preserve..w.end]);

    try w.flush();

    try std.testing.expectEqualStrings(expected_out, fw.buffered());
}

test {
    _ = Limited;
}
